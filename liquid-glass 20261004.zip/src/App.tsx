import React, { useState, useEffect, useRef, useCallback } from 'react';
import { defaultGlassConfig, GlassConfig } from './config';
import LeftSidebar from './components/LeftSidebar';

import { vertexShaderSource, fragmentShaderSource } from './shaders';

function createShader(gl: WebGLRenderingContext, type: number, source: string) {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error(gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function createProgram(gl: WebGLRenderingContext, vs: WebGLShader, fs: WebGLShader) {
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error(gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }
  return program;
}

function hexToVec4(hex: string, opacityPercent: number): [number, number, number, number] {
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c.split('').map((x) => x + x).join('');
  }
  const num = parseInt(c || '000000', 16);
  const r = ((num >> 16) & 255) / 255;
  const g = ((num >> 8) & 255) / 255;
  const b = (num & 255) / 255;
  const a = Math.max(0, Math.min(100, opacityPercent)) / 100;
  return [r, g, b, a];
}

function hslaToVec4(h: number, sPercent: number, lPercent: number, aPercent: number): [number, number, number, number] {
  const s = sPercent / 100;
  const l = lPercent / 100;
  const k = (n: number) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [f(0), f(8), f(4), aPercent / 100];
}

function sampleSourceLuminance(source: CanvasImageSource): number {
  try {
    const offCanvas = document.createElement('canvas');
    offCanvas.width = 32;
    offCanvas.height = 32;
    const ctx = offCanvas.getContext('2d');
    if (!ctx) return 0.5;
    ctx.drawImage(source, 0, 0, 32, 32);
    const data = ctx.getImageData(0, 0, 32, 32).data;
    let sum = 0;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i] / 255;
      const g = data[i + 1] / 255;
      const b = data[i + 2] / 255;
      sum += 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    return sum / (32 * 32);
  } catch {
    return 0.5;
  }
}

function computeMaps(source: CanvasImageSource): { lumData: Float32Array | null; textData: Float32Array | null } {
  try {
    const c = document.createElement('canvas');
    c.width = 64;
    c.height = 64;
    const ctx = c.getContext('2d');
    if (!ctx) return { lumData: null, textData: null };
    ctx.drawImage(source, 0, 0, 64, 64);
    const imgData = ctx.getImageData(0, 0, 64, 64);
    const pixels = imgData.data;

    const lumMap = new Float32Array(64 * 64);
    const edgeMap = new Float32Array(64 * 64);
    const textDensityMap = new Float32Array(64 * 64);

    for (let i = 0; i < 64 * 64; i++) {
      const pIdx = i * 4;
      const r = pixels[pIdx] / 255;
      const g = pixels[pIdx + 1] / 255;
      const b = pixels[pIdx + 2] / 255;
      lumMap[i] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }

    // High-pass Sobel edge gradient detection for character strokes
    for (let y = 1; y < 63; y++) {
      for (let x = 1; x < 63; x++) {
        const idx = y * 64 + x;
        const gx = lumMap[idx + 1] - lumMap[idx - 1];
        const gy = lumMap[idx + 64] - lumMap[idx - 64];
        const grad = Math.hypot(gx, gy);
        edgeMap[idx] = grad > 0.07 ? grad : 0.0;
      }
    }

    // Spatial pooling over a 5x5 window to measure stroke frequency / text cluster density
    for (let y = 2; y < 62; y++) {
      for (let x = 2; x < 62; x++) {
        let sum = 0;
        for (let dy = -2; dy <= 2; dy++) {
          for (let dx = -2; dx <= 2; dx++) {
            sum += edgeMap[(y + dy) * 64 + (x + dx)];
          }
        }
        textDensityMap[y * 64 + x] = sum / 25.0;
      }
    }

    return { lumData: lumMap, textData: textDensityMap };
  } catch {
    return { lumData: null, textData: null };
  }
}

interface GlassItem {
  id: number;
  shapeType: 'capsule' | 'rounded_rect' | 'circle';
  rectW: number;
  rectH: number;
  cornerRadius: number;
  size?: number;
  pos: { x: number; y: number };
  targetPos: { x: number; y: number };
  velocity: { x: number; y: number };
  clickScale: number;
  targetClickScale: number;
  clickScaleVel: number;
  isDragging: boolean;
  dragOffset: { x: number; y: number };
  anchorPos?: { x: number; y: number };
  whiteness: number;
  currLum?: number;
}

const getDefaultGlasses = (w: number, h: number): GlassItem[] => {
  const cx = w / 2;
  const cy = h / 2;
  return [
    {
      id: 1,
      shapeType: 'capsule',
      rectW: 280,
      rectH: 110,
      cornerRadius: 55,
      pos: { x: cx - 280, y: cy },
      targetPos: { x: cx - 280, y: cy },
      velocity: { x: 0, y: 0 },
      clickScale: 1.0,
      targetClickScale: 1.0,
      clickScaleVel: 0.0,
      isDragging: false,
      dragOffset: { x: 0, y: 0 },
      whiteness: 0.0,
      currLum: 0.5,
    },
    {
      id: 2,
      shapeType: 'rounded_rect',
      rectW: 240,
      rectH: 160,
      cornerRadius: 36,
      pos: { x: cx, y: cy },
      targetPos: { x: cx, y: cy },
      velocity: { x: 0, y: 0 },
      clickScale: 1.0,
      targetClickScale: 1.0,
      clickScaleVel: 0.0,
      isDragging: false,
      dragOffset: { x: 0, y: 0 },
      whiteness: 0.0,
      currLum: 0.5,
    },
    {
      id: 3,
      shapeType: 'circle',
      rectW: 150,
      rectH: 150,
      cornerRadius: 75,
      size: 75,
      pos: { x: cx + 280, y: cy },
      targetPos: { x: cx + 280, y: cy },
      velocity: { x: 0, y: 0 },
      clickScale: 1.0,
      targetClickScale: 1.0,
      clickScaleVel: 0.0,
      isDragging: false,
      dragOffset: { x: 0, y: 0 },
      whiteness: 0.0,
      currLum: 0.5,
    },
  ];
};

export default function App() {
  const [config, setConfig] = useState<GlassConfig>(defaultGlassConfig);
  const [isDragOver, setIsDragOver] = useState(false);
  const [glassCount, setGlassCount] = useState(3);
  const [isPinned, setIsPinned] = useState(false);
  const [viewMode, setViewMode] = useState<'canvas' | 'modal' | 'menu'>('modal');
  const [bgLuminance, setBgLuminance] = useState(0.5);
  const bgLuminanceRef = useRef(0.5);
  const currLumRef = useRef(0.5);
  const currBlurRef = useRef(0.0);
  const macroDataRef = useRef<Float32Array | null>(null);
  const textDensityMapRef = useRef<Float32Array | null>(null);

  const isPinnedRef = useRef(false);
  isPinnedRef.current = isPinned;

  const configRef = useRef<GlassConfig>(config);
  configRef.current = config;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const glRef = useRef<WebGLRenderingContext | null>(null);
  const programRef = useRef<WebGLProgram | null>(null);
  const textureRef = useRef<WebGLTexture | null>(null);
  const offscreenCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const uniformsRef = useRef<Record<string, WebGLUniformLocation | null>>({});
  const texResRef = useRef<{ w: number; h: number }>({ w: 1, h: 1 });

  const nextGlassId = useRef(4);
  const glassesRef = useRef<GlassItem[]>(
    getDefaultGlasses(
      typeof window !== 'undefined' ? window.innerWidth : 1200,
      typeof window !== 'undefined' ? window.innerHeight : 800
    )
  );
  const activeGlassId = useRef<number | null>(null);
  const isAnimating = useRef(false);
  const renderPending = useRef(false);
  const startAnimRef = useRef<(() => void) | null>(null);

  const gyroRef = useRef({
    baseBeta: null as number | null,
    baseGamma: null as number | null,
    tiltX: 0,
    tiltY: 0,
    currTiltX: 0,
    currTiltY: 0,
    tiltVelX: 0,
    tiltVelY: 0,
    highlightAngleOffset: 0,
    currHighlightAngleOffset: 0,
    hlAngleVel: 0,
    hasGyro: false,
  });

  const clickGlowRef = useRef({
    active: false,
    isHolding: false,
    progress: 0.0,
    intensity: 0.0,
    radius: 130.0,
    glassId: 1,
    offset: { x: 0, y: 0 },
    absPos: { x: 0, y: 0 },
    initialPos: { x: 0, y: 0 },
  });

  const getGlassBounds = useCallback((g: GlassItem) => {
    let totalW = 0, totalH = 0, corner = 0, spineW = 0, spineH = 0;

    if (g.shapeType === 'circle') {
      const sz = g.size || (g.cornerRadius ? g.cornerRadius : 75);
      totalW = sz * 2;
      totalH = sz * 2;
      corner = sz;
      spineW = 0;
      spineH = 0;
    } else if (g.shapeType === 'capsule') {
      totalW = g.rectW;
      totalH = g.rectH;
      corner = Math.min(totalW, totalH) / 2;
      spineW = Math.max(0, totalW / 2 - corner);
      spineH = Math.max(0, totalH / 2 - corner);
    } else {
      totalW = g.rectW;
      totalH = g.rectH;
      corner = Math.min(g.cornerRadius, Math.min(totalW, totalH) / 2);
      spineW = Math.max(0, totalW / 2 - corner);
      spineH = Math.max(0, totalH / 2 - corner);
    }
    corner = Math.max(2, corner);
    return { totalW, totalH, corner, spineW, spineH };
  }, []);

  const getShapeBounds = useCallback(() => {
    const { shape } = configRef.current;
    let totalW = 0, totalH = 0, corner = 0, spineW = 0, spineH = 0;

    if (shape.type === 'circle') {
      totalW = shape.size * 2;
      totalH = shape.size * 2;
      corner = shape.size;
      spineW = 0;
      spineH = 0;
    } else if (shape.type === 'capsule') {
      totalW = shape.rectW;
      totalH = shape.rectH;
      corner = Math.min(totalW, totalH) / 2;
      spineW = Math.max(0, totalW / 2 - corner);
      spineH = Math.max(0, totalH / 2 - corner);
    } else {
      totalW = shape.rectW;
      totalH = shape.rectH;
      corner = Math.min(shape.cornerRadius, Math.min(totalW, totalH) / 2);
      spineW = Math.max(0, totalW / 2 - corner);
      spineH = Math.max(0, totalH / 2 - corner);
    }
    corner = Math.max(2, corner);
    return { totalW, totalH, corner, spineW, spineH };
  }, []);

  const getGlassOpticalEnvironment = useCallback((posX: number, posY: number) => {
    const lumData = macroDataRef.current;
    const textData = textDensityMapRef.current;
    if (!lumData) return { lum: bgLuminanceRef.current, textBlur: 0.0 };
    const screenAspect = window.innerWidth / Math.max(1, window.innerHeight);
    const bgW = texResRef.current.w;
    const bgH = texResRef.current.h;
    if (bgW < 1 || bgH < 1) return { lum: bgLuminanceRef.current, textBlur: 0.0 };
    const imgAspect = bgW / bgH;

    let u = posX / Math.max(1, window.innerWidth);
    let v = posY / Math.max(1, window.innerHeight);

    if (screenAspect < imgAspect) {
      const uvScaleX = screenAspect / imgAspect;
      const uvOffsetX = (1.0 - uvScaleX) * 0.5;
      u = u * uvScaleX + uvOffsetX;
    } else {
      const uvScaleY = imgAspect / screenAspect;
      const uvOffsetY = (1.0 - uvScaleY) * 0.5;
      v = v * uvScaleY + uvOffsetY;
    }

    const col = Math.max(0, Math.min(63, Math.floor(Math.max(0, Math.min(1, u)) * 63)));
    const row = Math.max(0, Math.min(63, Math.floor(Math.max(0, Math.min(1, v)) * 63)));
    const idx = row * 64 + col;

    const lum = lumData[idx];
    const textVal = textData ? textData[idx] : 0.0;
    // Map text density to blur: 0px to max 5.0px (more text = higher frosted blur)
    const textBlur = Math.min(5.0, Math.max(0.0, textVal * 22.0));

    return { lum, textBlur };
  }, []);

  const renderFrame = useCallback(() => {
    const gl = glRef.current;
    const program = programRef.current;
    const uniforms = uniformsRef.current;
    const cfg = configRef.current;
    if (!gl || !program) return;

    if (!textureRef.current) {
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 0]));
      textureRef.current = tex;
    }
    const texture = textureRef.current;

    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    gl.useProgram(program);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);

    if (cfg.bg.type === 'video' && videoRef.current && videoRef.current.readyState >= 2) {
      gl.activeTexture(gl.TEXTURE0);
      let vidSource: TexImageSource = videoRef.current;
      const bgBlur = cfg.bg.blur || 0;
      if (bgBlur > 0.05) {
        if (!offscreenCanvasRef.current) {
          offscreenCanvasRef.current = document.createElement('canvas');
        }
        const offCanvas = offscreenCanvasRef.current;
        const vw = videoRef.current.videoWidth || 1280;
        const vh = videoRef.current.videoHeight || 720;
        if (offCanvas.width !== vw || offCanvas.height !== vh) {
          offCanvas.width = vw;
          offCanvas.height = vh;
        }
        const ctx = offCanvas.getContext('2d');
        if (ctx) {
          const screenW = window.innerWidth;
          const screenH = window.innerHeight;
          const screenAspect = screenW / Math.max(1, screenH);
          const vidAspect = vw / Math.max(1, vh);
          const scale = screenAspect < vidAspect ? (vh / screenH) : (vw / screenW);
          const blurPxInTex = bgBlur * Math.max(1.0, scale);
          ctx.clearRect(0, 0, vw, vh);
          ctx.drawImage(videoRef.current, 0, 0, vw, vh);
          ctx.filter = `blur(${blurPxInTex}px)`;
          const pad = Math.min(Math.ceil(blurPxInTex * 2), Math.min(vw, vh) / 4);
          ctx.drawImage(videoRef.current, -pad, -pad, vw + pad * 2, vh + pad * 2);
          vidSource = offCanvas;
        }
      }
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, vidSource);
    }

    gl.uniform1i(uniforms.u_texture, 0);

    const dpr = Math.min(Math.max(window.devicePixelRatio || 1.0, 1.5), 2.0);
    const actualDpr = window.devicePixelRatio || 1.0;
    const highlightScale = dpr / actualDpr;
    gl.uniform2f(uniforms.u_resolution, gl.canvas.width, gl.canvas.height);
    gl.uniform2f(uniforms.u_screenSize, window.innerWidth, window.innerHeight);
    gl.uniform1f(uniforms.u_cssRatio, window.innerWidth / window.innerHeight);
    gl.uniform1f(uniforms.u_highlightScale, highlightScale);

    // Precompute cover UV transform on CPU to completely eliminate per-pixel division/branching in fragment shader
    const screenAspect = window.innerWidth / Math.max(1, window.innerHeight);
    let uvScaleX = 1.0;
    let uvScaleY = 1.0;
    let uvOffsetX = 0.0;
    let uvOffsetY = 0.0;
    const bgW = texResRef.current.w;
    const bgH = texResRef.current.h;
    if (bgW >= 1.0 && bgH >= 1.0) {
      const imgAspect = bgW / bgH;
      if (screenAspect < imgAspect) {
        uvScaleX = screenAspect / imgAspect;
        uvOffsetX = (1.0 - uvScaleX) * 0.5;
      } else {
        uvScaleY = imgAspect / screenAspect;
        uvOffsetY = (1.0 - uvScaleY) * 0.5;
      }
    }
    gl.uniform2f(uniforms.u_uvScale, uvScaleX, uvScaleY);
    gl.uniform2f(uniforms.u_uvOffset, uvOffsetX, uvOffsetY);

    // 高光入射角度：0°=正右侧, 45°=右上角, 90°=正上方(默认上下90度), 135°=左上角, 180°=正左侧, 225°=左下角, 270°=正下方, 315°=右下角
    const fixedHighlightAngle = cfg.highlight.lightAngle !== undefined ? cfg.highlight.lightAngle : 90.0;
    const rad = (fixedHighlightAngle * Math.PI) / 180.0;
    // 屏幕空间 (X向右, Y向下): 正角度向上旋转，-sin(rad) 使得 90° 指向正上方(-Y), 45° 指向右上角(+X, -Y)
    const lx = Math.cos(rad);
    const ly = -Math.sin(rad);

    // 阴影固定：直接使用用户在面板中配置的固定 Offset，不随陀螺仪或屏幕中心视差漂移
    const outerX = cfg.outerShadow.offsetX;
    const outerY = cfg.outerShadow.offsetY;

    gl.uniform1f(uniforms.u_outerShadowEnable, cfg.outerShadow.enabled ? 1.0 : 0.0);
    const outerCol = hexToVec4(cfg.outerShadow.color, cfg.outerShadow.opacity);
    gl.uniform4f(uniforms.u_outerShadowColor, outerCol[0], outerCol[1], outerCol[2], outerCol[3]);
    gl.uniform2f(uniforms.u_outerShadowOffset, outerX * dpr, outerY * dpr);
    gl.uniform1f(uniforms.u_outerShadowBlur, cfg.outerShadow.blur * dpr);

    // Inner shadow (固定)
    const innerX = cfg.innerShadow.offsetX;
    const innerY = cfg.innerShadow.offsetY;

    gl.uniform1f(uniforms.u_innerShadowEnable, cfg.innerShadow.enabled ? 1.0 : 0.0);
    const innerCol = hexToVec4(cfg.innerShadow.color, cfg.innerShadow.opacity);
    gl.uniform4f(uniforms.u_innerShadowColor, innerCol[0], innerCol[1], innerCol[2], innerCol[3]);
    gl.uniform2f(uniforms.u_innerShadowOffset, innerX * dpr, innerY * dpr);
    gl.uniform1f(uniforms.u_innerShadowBlur, cfg.innerShadow.blur * dpr);

    const { corner, spineW, spineH } = getShapeBounds();

    let shapeVal = 0.0;
    if (cfg.shape.type === 'capsule') shapeVal = 1.0;
    else if (cfg.shape.type === 'circle') shapeVal = 2.0;
    gl.uniform1f(uniforms.u_shapeType, shapeVal);
    const effectiveBlur = Math.min(5.0, Math.max(0.0, cfg.optics.blurRadius + currBlurRef.current));
    gl.uniform1f(uniforms.u_blurRadius, effectiveBlur);
    gl.uniform1f(uniforms.u_bgBlur, Math.min(10.0, Math.max(0.0, cfg.bg.blur || 0.0)));

    gl.uniform1f(uniforms.u_colorMode, cfg.color.mode === 'gradient' ? 1.0 : 0.0);
    gl.uniform1f(uniforms.u_gradientRatio, cfg.color.gradient.ratio / 100);

    gl.uniform1f(uniforms.u_highlightEnable, cfg.highlight.enabled ? 1.0 : 0.0);
    gl.uniform1f(uniforms.u_highlightFeather, cfg.highlight.feather);
    gl.uniform1f(uniforms.u_highlightWidth, cfg.highlight.width * dpr);
    gl.uniform1f(uniforms.u_highlightWhiteOpacity, cfg.highlight.whiteOpacity);
    gl.uniform1f(uniforms.u_highlightSampleOpacity, cfg.highlight.sampleOpacity);
    gl.uniform1f(uniforms.u_highlightReflectDist, cfg.highlight.reflectDist * dpr);
    gl.uniform1f(uniforms.u_highlightClarity, cfg.highlight.clarity);
    gl.uniform1f(uniforms.u_highlightBlur, cfg.highlight.blur * dpr);

    if (cfg.color.mode === 'solid') {
      const col = hslaToVec4(cfg.color.solid.h, cfg.color.solid.s, cfg.color.solid.l, cfg.color.solid.a);
      gl.uniform4f(uniforms.u_glassColor, col[0], col[1], col[2], col[3]);
      gl.uniform4f(uniforms.u_glassColor2, col[0], col[1], col[2], col[3]);
    } else {
      const topCol = hslaToVec4(cfg.color.gradient.top.h, cfg.color.gradient.top.s, cfg.color.gradient.top.l, cfg.color.gradient.top.a);
      const bottomCol = hslaToVec4(cfg.color.gradient.bottom.h, cfg.color.gradient.bottom.s, cfg.color.gradient.bottom.l, cfg.color.gradient.bottom.a);
      gl.uniform4f(uniforms.u_glassColor, topCol[0], topCol[1], topCol[2], topCol[3]);
      gl.uniform4f(uniforms.u_glassColor2, bottomCol[0], bottomCol[1], bottomCol[2], bottomCol[3]);
    }

    gl.uniform2f(uniforms.u_boxSize, spineW * dpr, spineH * dpr);
    gl.uniform1f(uniforms.u_glassRadius, corner * dpr);

    const hasBg = (cfg.bg.src && cfg.bg.src.length > 0) ? 1.0 : 0.0;
    gl.uniform1f(uniforms.u_hasBg, hasBg);
    gl.uniform1f(uniforms.u_adaptiveOpacity, (cfg.color.adaptiveOpacity ?? true) ? 1.0 : 0.0);
    gl.uniform1f(uniforms.u_bgLuminance, currLumRef.current);

    gl.uniform1f(uniforms.u_refraction, cfg.optics.refraction / 100);
    gl.uniform1f(uniforms.u_edgeWidth, cfg.optics.edgeWidth / 100);
    gl.uniform1f(uniforms.u_dispersion, cfg.optics.dispersion / 100);
    gl.uniform1f(uniforms.u_liquidBridge, cfg.optics.liquidBridge);
    gl.uniform1f(uniforms.u_fluidIntensity, cfg.optics.fluidIntensity);
    gl.uniform2f(uniforms.u_lightDir, lx, ly);

    // Click Halo / Localized White Glow
    const clickGlow = clickGlowRef.current;
    let glowX = 0, glowY = 0;
    if (clickGlow.active && clickGlow.intensity > 0.001) {
      const targetGlass = glassesRef.current.find(g => g.id === clickGlow.glassId) || glassesRef.current[0];
      if (targetGlass) {
        glowX = (targetGlass.pos.x + clickGlow.offset.x) * dpr;
        glowY = (targetGlass.pos.y + clickGlow.offset.y) * dpr;
      } else {
        glowX = clickGlow.absPos.x * dpr;
        glowY = clickGlow.absPos.y * dpr;
      }
    }
    gl.uniform2f(uniforms.u_clickGlowPos, glowX, glowY);
    gl.uniform1f(uniforms.u_clickGlowIntensity, clickGlow.active ? clickGlow.intensity : 0.0);
    gl.uniform1f(uniforms.u_clickGlowRadius, clickGlow.radius * dpr);
    gl.uniform1f(uniforms.u_clickGlowProgress, clickGlow.progress);

    const activeIndex = glassesRef.current.findIndex(g => g.id === activeGlassId.current);
    let pullVecX = 0, pullVecY = 0;
    if (isPinnedRef.current && activeIndex !== -1 && clickGlow.active && (clickGlow as any).initialPos) {
      pullVecX = (clickGlow.absPos.x - (clickGlow as any).initialPos.x) * dpr * 0.7;
      pullVecY = (clickGlow.absPos.y - (clickGlow as any).initialPos.y) * dpr * 0.7;
    }
    gl.uniform2f(uniforms.u_pullVec, pullVecX, pullVecY);
    gl.uniform1i(uniforms.u_activeGlassIndex, activeIndex);

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    const maxGlasses = 12;
    const numGlasses = Math.min(glassesRef.current.length, maxGlasses);
    const glassPosArr = new Float32Array(maxGlasses * 2);
    const velocityArr = new Float32Array(maxGlasses * 2);
    const clickScaleArr = new Float32Array(maxGlasses);
    const connectedMaskArr = new Float32Array(maxGlasses);
    const whitenessArr = new Float32Array(maxGlasses);
    const bgLuminanceArr = new Float32Array(maxGlasses);
    const shapeTypeArr = new Float32Array(maxGlasses);
    const boxSizeArr = new Float32Array(maxGlasses * 2);
    const glassRadiusArr = new Float32Array(maxGlasses);

    for (let i = 0; i < maxGlasses; i++) {
      if (i < numGlasses) {
        const glass = glassesRef.current[i];
        glassPosArr[i * 2] = glass.pos.x * dpr;
        glassPosArr[i * 2 + 1] = glass.pos.y * dpr;
        velocityArr[i * 2] = glass.velocity.x * dpr;
        velocityArr[i * 2 + 1] = glass.velocity.y * dpr;
        clickScaleArr[i] = Math.max(0.01, glass.clickScale);
        whitenessArr[i] = glass.whiteness || 0.0;
        bgLuminanceArr[i] = typeof glass.currLum === 'number' ? glass.currLum : 0.5;

        let sTypeVal = 0.0;
        if (glass.shapeType === 'capsule') sTypeVal = 1.0;
        else if (glass.shapeType === 'circle') sTypeVal = 2.0;
        shapeTypeArr[i] = sTypeVal;

        const gBounds = getGlassBounds(glass);
        boxSizeArr[i * 2] = gBounds.spineW * dpr;
        boxSizeArr[i * 2 + 1] = gBounds.spineH * dpr;
        glassRadiusArr[i] = gBounds.corner * dpr;
      } else {
        clickScaleArr[i] = 1.0;
        bgLuminanceArr[i] = 0.5;
      }
    }

    gl.uniform2fv(uniforms.u_glassPosArr, glassPosArr);
    gl.uniform2fv(uniforms.u_velocityArr, velocityArr);
    gl.uniform1fv(uniforms.u_clickScaleArr, clickScaleArr);
    gl.uniform1fv(uniforms.u_connectedMaskArr, connectedMaskArr);
    gl.uniform1fv(uniforms.u_whitenessArr, whitenessArr);
    gl.uniform1fv(uniforms.u_bgLuminanceArr, bgLuminanceArr);
    gl.uniform1fv(uniforms.u_shapeTypeArr, shapeTypeArr);
    gl.uniform2fv(uniforms.u_boxSizeArr, boxSizeArr);
    gl.uniform1fv(uniforms.u_glassRadiusArr, glassRadiusArr);
    gl.uniform1i(uniforms.u_numGlasses, numGlasses);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    if (cfg.bg.type === 'video' && videoRef.current && !videoRef.current.paused) {
      requestAnimationFrame(renderFrame);
    }
  }, [getShapeBounds]);

  const requestRender = useCallback(() => {
    if (!renderPending.current) {
      renderPending.current = true;
      requestAnimationFrame(() => {
        renderPending.current = false;
        renderFrame();
      });
    }
  }, [renderFrame]);

  // Initial WebGL Setup (Run strictly ONCE on mount)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: true });
    if (!gl) return;
    glRef.current = gl;

    const vs = createShader(gl, gl.VERTEX_SHADER, vertexShaderSource);
    const fs = createShader(gl, gl.FRAGMENT_SHADER, fragmentShaderSource);
    if (!vs || !fs) return;

    const program = createProgram(gl, vs, fs);
    if (!program) return;
    programRef.current = program;

    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    const positions = new Float32Array([-1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, 1.0]);
    gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);

    const positionLocation = gl.getAttribLocation(program, 'a_position');
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

    uniformsRef.current = {
      u_texture: gl.getUniformLocation(program, 'u_texture'),
      u_resolution: gl.getUniformLocation(program, 'u_resolution'),
      u_screenSize: gl.getUniformLocation(program, 'u_screenSize'),
      u_texResolution: gl.getUniformLocation(program, 'u_texResolution'),
      u_uvScale: gl.getUniformLocation(program, 'u_uvScale'),
      u_uvOffset: gl.getUniformLocation(program, 'u_uvOffset'),
      u_glassPosArr: gl.getUniformLocation(program, 'u_glassPosArr'),
      u_glassRadius: gl.getUniformLocation(program, 'u_glassRadius'),
      u_refraction: gl.getUniformLocation(program, 'u_refraction'),
      u_edgeWidth: gl.getUniformLocation(program, 'u_edgeWidth'),
      u_dispersion: gl.getUniformLocation(program, 'u_dispersion'),
      u_lightDir: gl.getUniformLocation(program, 'u_lightDir'),
      u_boxSize: gl.getUniformLocation(program, 'u_boxSize'),
      u_shapeType: gl.getUniformLocation(program, 'u_shapeType'),
      u_blurRadius: gl.getUniformLocation(program, 'u_blurRadius'),
      u_bgBlur: gl.getUniformLocation(program, 'u_bgBlur'),
      u_glassColor: gl.getUniformLocation(program, 'u_glassColor'),
      u_glassColor2: gl.getUniformLocation(program, 'u_glassColor2'),
      u_colorMode: gl.getUniformLocation(program, 'u_colorMode'),
      u_gradientRatio: gl.getUniformLocation(program, 'u_gradientRatio'),
      u_highlightEnable: gl.getUniformLocation(program, 'u_highlightEnable'),
      u_highlightFeather: gl.getUniformLocation(program, 'u_highlightFeather'),
      u_highlightWidth: gl.getUniformLocation(program, 'u_highlightWidth'),
      u_highlightWhiteOpacity: gl.getUniformLocation(program, 'u_highlightWhiteOpacity'),
      u_highlightSampleOpacity: gl.getUniformLocation(program, 'u_highlightSampleOpacity'),
      u_highlightReflectDist: gl.getUniformLocation(program, 'u_highlightReflectDist'),
      u_highlightClarity: gl.getUniformLocation(program, 'u_highlightClarity'),
      u_highlightBlur: gl.getUniformLocation(program, 'u_highlightBlur'),
      u_liquidBridge: gl.getUniformLocation(program, 'u_liquidBridge'),
      u_fluidIntensity: gl.getUniformLocation(program, 'u_fluidIntensity'),
      u_velocityArr: gl.getUniformLocation(program, 'u_velocityArr'),
      u_clickScaleArr: gl.getUniformLocation(program, 'u_clickScaleArr'),
      u_numGlasses: gl.getUniformLocation(program, 'u_numGlasses'),
      u_cssRatio: gl.getUniformLocation(program, 'u_cssRatio'),
      u_highlightScale: gl.getUniformLocation(program, 'u_highlightScale'),
      u_outerShadowEnable: gl.getUniformLocation(program, 'u_outerShadowEnable'),
      u_outerShadowColor: gl.getUniformLocation(program, 'u_outerShadowColor'),
      u_outerShadowOffset: gl.getUniformLocation(program, 'u_outerShadowOffset'),
      u_outerShadowBlur: gl.getUniformLocation(program, 'u_outerShadowBlur'),
      u_innerShadowEnable: gl.getUniformLocation(program, 'u_innerShadowEnable'),
      u_innerShadowColor: gl.getUniformLocation(program, 'u_innerShadowColor'),
      u_innerShadowOffset: gl.getUniformLocation(program, 'u_innerShadowOffset'),
      u_innerShadowBlur: gl.getUniformLocation(program, 'u_innerShadowBlur'),
      u_clickGlowPos: gl.getUniformLocation(program, 'u_clickGlowPos'),
      u_clickGlowIntensity: gl.getUniformLocation(program, 'u_clickGlowIntensity'),
      u_clickGlowRadius: gl.getUniformLocation(program, 'u_clickGlowRadius'),
      u_clickGlowProgress: gl.getUniformLocation(program, 'u_clickGlowProgress'),
      u_pullVec: gl.getUniformLocation(program, 'u_pullVec'),
      u_activeGlassIndex: gl.getUniformLocation(program, 'u_activeGlassIndex'),
      u_connectedMaskArr: gl.getUniformLocation(program, 'u_connectedMaskArr'),
      u_whitenessArr: gl.getUniformLocation(program, 'u_whitenessArr'),
      u_bgLuminanceArr: gl.getUniformLocation(program, 'u_bgLuminanceArr'),
      u_hasBg: gl.getUniformLocation(program, 'u_hasBg'),
      u_adaptiveOpacity: gl.getUniformLocation(program, 'u_adaptiveOpacity'),
      u_bgLuminance: gl.getUniformLocation(program, 'u_bgLuminance'),
      u_shapeTypeArr: gl.getUniformLocation(program, 'u_shapeTypeArr'),
      u_boxSizeArr: gl.getUniformLocation(program, 'u_boxSizeArr'),
      u_glassRadiusArr: gl.getUniformLocation(program, 'u_glassRadiusArr'),
    };

    const handleResize = () => {
      const dpr = Math.min(Math.max(window.devicePixelRatio || 1.0, 1.5), 2.0);
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
      renderFrame();
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    // Initial frame 0 paint
    renderFrame();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [renderFrame]);

  const updateImageTexture = useCallback(() => {
    const gl = glRef.current;
    const program = programRef.current;
    const img = imgRef.current;
    const cfg = configRef.current;
    if (!gl || !program || !img || !img.complete || img.naturalWidth === 0) return;

    if (!textureRef.current) {
      const tex = gl.createTexture();
      if (!tex) return;
      textureRef.current = tex;
    }
    const texture = textureRef.current;

    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    const w = img.naturalWidth;
    const h = img.naturalHeight;
    texResRef.current = { w, h };

    const bgBlur = cfg.bg.blur || 0;
    let sourceToUpload: TexImageSource = img;

    // 让背景在送入 WebGL 纹理前先完成物理高斯模糊（使光线进入玻璃前就是已模糊背景，透过玻璃后决不会反变清晰）
    if (bgBlur > 0.05) {
      if (!offscreenCanvasRef.current) {
        offscreenCanvasRef.current = document.createElement('canvas');
      }
      const offCanvas = offscreenCanvasRef.current;
      offCanvas.width = w;
      offCanvas.height = h;
      const ctx = offCanvas.getContext('2d');
      if (ctx) {
        const screenW = window.innerWidth;
        const screenH = window.innerHeight;
        const screenAspect = screenW / Math.max(1, screenH);
        const imgAspect = w / Math.max(1, h);
        const scale = screenAspect < imgAspect ? (h / screenH) : (w / screenW);
        const blurPxInTex = bgBlur * Math.max(1.0, scale);

        ctx.clearRect(0, 0, w, h);
        // 先绘制原图打底
        ctx.drawImage(img, 0, 0, w, h);
        // 施加原生硬件高斯模糊，外扩微小内边距防止边缘暗角
        ctx.filter = `blur(${blurPxInTex}px)`;
        const pad = Math.min(Math.ceil(blurPxInTex * 2), Math.min(w, h) / 4);
        ctx.drawImage(img, -pad, -pad, w + pad * 2, h + pad * 2);
        sourceToUpload = offCanvas;
      }
    }

    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, sourceToUpload);

    const maps = computeMaps(img);
    macroDataRef.current = maps.lumData;
    textDensityMapRef.current = maps.textData;

    const lum = sampleSourceLuminance(img);
    bgLuminanceRef.current = lum;
    setBgLuminance(lum);

    gl.useProgram(program);
    gl.uniform2f(uniformsRef.current.u_texResolution, w, h);

    requestRender();
  }, [requestRender]);

  const handleImageLoad = useCallback(() => {
    updateImageTexture();
  }, [updateImageTexture]);

  const handleVideoLoad = useCallback(() => {
    const gl = glRef.current;
    const program = programRef.current;
    const video = videoRef.current;
    if (!gl || !program || !video) return;

    if (textureRef.current) gl.deleteTexture(textureRef.current);
    const texture = gl.createTexture();
    if (!texture) return;
    textureRef.current = texture;

    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    if (video.readyState >= 2) {
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
      const maps = computeMaps(video);
      macroDataRef.current = maps.lumData;
      textDensityMapRef.current = maps.textData;
      const lum = sampleSourceLuminance(video);
      bgLuminanceRef.current = lum;
      setBgLuminance(lum);
    }

    texResRef.current = { w: video.videoWidth, h: video.videoHeight };
    gl.useProgram(program);
    gl.uniform2f(uniformsRef.current.u_texResolution, video.videoWidth, video.videoHeight);

    video.play().catch(() => {});
    requestRender();
  }, [requestRender]);

  // Request render whenever config changes (instant uniform update, no recompile!)
  useEffect(() => {
    requestRender();
  }, [config, requestRender]);

  // Background Reload when type/src/blur changes
  useEffect(() => {
    if (config.bg.type === 'image' || config.bg.type === 'webpage') {
      updateImageTexture();
    } else if (config.bg.type === 'video' && videoRef.current && videoRef.current.readyState >= 2) {
      handleVideoLoad();
    }
  }, [config.bg.type, config.bg.src, config.bg.blur, updateImageTexture, handleVideoLoad]);

  // Gestures & Physics Setup (Bound once on mount)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const getPointerPos = (e: MouseEvent | TouchEvent) => {
      if ('touches' in e && e.touches.length > 0) {
        return { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
      return { x: (e as MouseEvent).clientX, y: (e as MouseEvent).clientY };
    };

    const startAnimation = () => {
      if (isAnimating.current) return;
      isAnimating.current = true;
      let lastTime = performance.now();

      const loop = (time: number) => {
        const dt = Math.min(time - lastTime, 32);
        lastTime = time;

        const dtMulti = Math.min(dt / 16.66, 2.0);
        const gyro = gyroRef.current;

        // 2nd-order Spring dynamics for Gyro / Tilt Inertia
        const springK = 0.16;      // Elastic acceleration towards target posture
        const damping = 0.72;      // Viscous damping for silky settle without jitter

        const forceX = (gyro.tiltX - gyro.currTiltX) * springK;
        const forceY = (gyro.tiltY - gyro.currTiltY) * springK;
        const forceHl = (gyro.highlightAngleOffset - gyro.currHighlightAngleOffset) * springK;

        gyro.tiltVelX = (gyro.tiltVelX + forceX * dtMulti) * Math.pow(damping, dtMulti);
        gyro.tiltVelY = (gyro.tiltVelY + forceY * dtMulti) * Math.pow(damping, dtMulti);
        gyro.hlAngleVel = (gyro.hlAngleVel + forceHl * dtMulti) * Math.pow(damping, dtMulti);

        gyro.currTiltX += gyro.tiltVelX * dtMulti;
        gyro.currTiltY += gyro.tiltVelY * dtMulti;
        gyro.currHighlightAngleOffset += gyro.hlAngleVel * dtMulti;

        let anyAnimating = false;
        if (
          Math.abs(gyro.tiltX - gyro.currTiltX) > 0.0001 ||
          Math.abs(gyro.tiltY - gyro.currTiltY) > 0.0001 ||
          Math.abs(gyro.tiltVelX) > 0.0001 ||
          Math.abs(gyro.tiltVelY) > 0.0001 ||
          Math.abs(gyro.hlAngleVel) > 0.01
        ) {
          anyAnimating = true;
        }

        // Click localized glow animation logic (Organic spring-damped lighting & fade-out)
        const glow = clickGlowRef.current;
        if (glow.active) {
          // Spread outwards animation bounded strictly within the active glass dimensions
          const { totalW, totalH } = getShapeBounds();
          const targetRadius = Math.max(totalW, totalH) * 1.3 + 30.0;
          const radiusLerp = 1.0 - Math.pow(1.0 - 0.15, dtMulti);
          glow.radius += (targetRadius - glow.radius) * radiusLerp;
          if (Math.abs(targetRadius - glow.radius) > 0.5) {
            anyAnimating = true;
          }

          if (glow.isHolding) {
            // Smoothly and organically brighten to full luminous intensity
            const targetIntensity = 1.0;
            const glowLerp = 1.0 - Math.pow(1.0 - 0.28, dtMulti);
            glow.intensity += (targetIntensity - glow.intensity) * glowLerp;
            if (Math.abs(targetIntensity - glow.intensity) > 0.005) {
              anyAnimating = true;
            }
          } else {
            // Natural smooth fade out
            const glowLerp = 1.0 - Math.pow(1.0 - 0.22, dtMulti);
            glow.intensity += (0.0 - glow.intensity) * glowLerp;
            if (glow.intensity <= 0.003) {
              glow.active = false;
              glow.intensity = 0.0;
            } else {
              anyAnimating = true;
            }
          }
        }

        const { shape } = configRef.current;
        const { corner, spineW, spineH } = getShapeBounds();
        const numGlasses = glassesRef.current.length;

        for (const glass of glassesRef.current) {
          const dx = glass.targetPos.x - glass.pos.x;
          const dy = glass.targetPos.y - glass.pos.y;
          const lerpFactor = 1.0 - Math.pow(1.0 - 0.25, dtMulti);

          if (glass.shapeType === 'circle' || shape.type === 'circle') {
            const vx = dx * lerpFactor;
            const vy = dy * lerpFactor;
            glass.pos.x += vx;
            glass.pos.y += vy;
            glass.velocity.x = vx / dtMulti;
            glass.velocity.y = vy / dtMulti;
          } else {
            const springForceX = dx * 0.18;
            const springForceY = dy * 0.18;
            glass.velocity.x += springForceX * dtMulti;
            glass.velocity.y += springForceY * dtMulti;
            glass.velocity.x *= Math.pow(0.62, dtMulti);
            glass.velocity.y *= Math.pow(0.62, dtMulti);
            glass.pos.x += glass.velocity.x * dtMulti;
            glass.pos.y += glass.velocity.y * dtMulti;
          }

          const springForceScale = (glass.targetClickScale - glass.clickScale) * 0.25;
          glass.clickScaleVel += springForceScale * dtMulti;
          glass.clickScaleVel *= Math.pow(0.75, dtMulti);
          glass.clickScale += glass.clickScaleVel * dtMulti;

          if (
            Math.abs(dx) >= 0.5 ||
            Math.abs(dy) >= 0.5 ||
            glass.isDragging ||
            Math.abs(glass.velocity.x) >= 0.1 ||
            Math.abs(glass.velocity.y) >= 0.1 ||
            Math.abs(glass.targetClickScale - glass.clickScale) >= 0.002 ||
            Math.abs(glass.clickScaleVel) >= 0.002
          ) {
            anyAnimating = true;
          } else {
            glass.pos.x = glass.targetPos.x;
            glass.pos.y = glass.targetPos.y;
            glass.velocity.x = 0;
            glass.velocity.y = 0;
            glass.clickScale = glass.targetClickScale;
            glass.clickScaleVel = 0;
          }
        }

        // Liquid bridge contact whitening animation (STRICTLY ONLY touching pairs turn milky white)
        if (numGlasses > 1) {
          const bridgeThreshold = Math.max(14.0, (configRef.current.optics.liquidBridge / 50.0) * 48.0 + 10.0);
          const adj = Array.from({ length: numGlasses }, () => Array(numGlasses).fill(false));

          for (let i = 0; i < numGlasses; i++) {
            for (let j = i + 1; j < numGlasses; j++) {
              const gA = glassesRef.current[i];
              const gB = glassesRef.current[j];
              const bA = getGlassBounds(gA);
              const bB = getGlassBounds(gB);
              const dx = Math.max(0, Math.abs(gA.pos.x - gB.pos.x) - (bA.spineW + bB.spineW));
              const dy = Math.max(0, Math.abs(gA.pos.y - gB.pos.y) - (bA.spineH + bB.spineH));
              const surfDist = Math.hypot(dx, dy) - (bA.corner + bB.corner);

              if (surfDist <= bridgeThreshold) {
                adj[i][j] = true;
                adj[j][i] = true;
              }
            }
          }

          // Whiten ONLY the glasses that are actually in contact with another glass
          for (let i = 0; i < numGlasses; i++) {
            const isTouching = adj[i].some((connected, j) => j !== i && connected);
            const targetW = isTouching ? 1.0 : 0.0;
            const glass = glassesRef.current[i];
            const prevW = glass.whiteness || 0.0;
            const wLerp = 1.0 - Math.pow(1.0 - 0.20, dtMulti);
            glass.whiteness = prevW + (targetW - prevW) * wLerp;
            if (Math.abs(targetW - glass.whiteness) > 0.002) {
              anyAnimating = true;
            }
          }
        } else if (numGlasses === 1) {
          const glass = glassesRef.current[0];
          if ((glass.whiteness || 0) > 0.001) {
            const wLerp = 1.0 - Math.pow(1.0 - 0.20, dtMulti);
            glass.whiteness = (glass.whiteness || 0) * (1.0 - wLerp);
            if (glass.whiteness <= 0.002) {
              glass.whiteness = 0.0;
            } else {
              anyAnimating = true;
            }
          }
        }

        // Per-glass independent adaptive luminance adaptation (Gentle deadzone, smooth natural response)
        if (configRef.current.color.adaptiveOpacity ?? true) {
          let maxBlur = 0;

          for (const g of glassesRef.current) {
            const { lum: envLum, textBlur: envBlur } = getGlassOpticalEnvironment(g.pos.x, g.pos.y);
            if (envBlur > maxBlur) {
              maxBlur = envBlur;
            }

            // Comfortable deadzone [0.42, 0.58]: keeps neutral backgrounds relaxed at 0.50
            let targetLum = 0.5;
            if (envLum < 0.42) {
              targetLum = 0.5 - (0.42 - envLum) * 1.15;
            } else if (envLum > 0.58) {
              targetLum = 0.5 + (envLum - 0.58) * 1.15;
            }
            targetLum = Math.max(0.0, Math.min(1.0, targetLum));

            const prevLum = typeof g.currLum === 'number' ? g.currLum : 0.5;
            const lumDiff = targetLum - prevLum;
            if (Math.abs(lumDiff) > 0.0005) {
              // Gentle, organic eye adaptation rate (0.04) per glass
              g.currLum = prevLum + lumDiff * 0.04;
              anyAnimating = true;
            } else {
              g.currLum = targetLum;
            }
          }

          const targetBlur = maxBlur;
          const prevBlur = currBlurRef.current;
          const blurDiff = targetBlur - prevBlur;
          if (Math.abs(blurDiff) > 0.02) {
            currBlurRef.current += blurDiff * 0.05;
            anyAnimating = true;
          } else {
            currBlurRef.current = targetBlur;
          }
        }

        renderFrame();

        if (!anyAnimating) {
          isAnimating.current = false;
        } else {
          requestAnimationFrame(loop);
        }
      };
      requestAnimationFrame(loop);
    };

    startAnimRef.current = startAnimation;

    const handleDown = (e: MouseEvent | TouchEvent) => {
      const pos = getPointerPos(e);

      let clickedGlass = null;
      for (let i = glassesRef.current.length - 1; i >= 0; i--) {
        const glass = glassesRef.current[i];
        const { corner: gCorner, spineW: gSpineW, spineH: gSpineH } = getGlassBounds(glass);
        let dx = Math.abs(pos.x - glass.pos.x);
        let dy = Math.abs(pos.y - glass.pos.y);
        dx = Math.max(0, dx - gSpineW);
        dy = Math.max(0, dy - gSpineH);

        if (Math.sqrt(dx * dx + dy * dy) <= gCorner) {
          clickedGlass = glass;
          glassesRef.current.splice(i, 1);
          glassesRef.current.push(glass);
          break;
        }
      }

      if (clickedGlass) {
        clickedGlass.isDragging = !isPinnedRef.current;
        clickedGlass.targetClickScale = 1.08;
        clickedGlass.dragOffset = { x: pos.x - clickedGlass.targetPos.x, y: pos.y - clickedGlass.targetPos.y };
        if (isPinnedRef.current) {
          clickedGlass.anchorPos = { x: clickedGlass.targetPos.x, y: clickedGlass.targetPos.y };
        }
        activeGlassId.current = clickedGlass.id;

        // Trigger localized soft white illumination & hold
        clickGlowRef.current = {
          active: true,
          isHolding: true,
          progress: 0.0,
          intensity: 0.15,
          radius: 0.0,
          glassId: clickedGlass.id,
          offset: { x: pos.x - clickedGlass.pos.x, y: pos.y - clickedGlass.pos.y },
          absPos: { x: pos.x, y: pos.y },
          initialPos: { x: pos.x, y: pos.y },
        };

        canvas.style.cursor = isPinnedRef.current ? 'crosshair' : 'grabbing';
        if (e.cancelable) e.preventDefault();
        startAnimation();
      }
    };

    const handleMove = (e: MouseEvent | TouchEvent) => {
      const pos = getPointerPos(e);
      const activeGlass = glassesRef.current.find((g) => g.id === activeGlassId.current);

      // Dynamic desktop mouse tilt simulation (only if no real gyro)
      if (!gyroRef.current.hasGyro && !('touches' in e)) {
        const normX = ((pos.x - window.innerWidth / 2) / (window.innerWidth / 2)) * 1.5;
        const normY = ((pos.y - window.innerHeight / 2) / (window.innerHeight / 2)) * 1.5;
        gyroRef.current.tiltX = Math.max(-2.0, Math.min(2.0, normX));
        gyroRef.current.tiltY = Math.max(-2.0, Math.min(2.0, normY));
        gyroRef.current.highlightAngleOffset = normX * 45.0 - normY * 30.0;
        startAnimation();
      }

      // Active pointer interaction: track glow inside glass or drag glass
      if (activeGlass) {
        const { corner: gCorner, spineW: gSpineW, spineH: gSpineH } = getGlassBounds(activeGlass);
        let dx = Math.abs(pos.x - activeGlass.pos.x);
        let dy = Math.abs(pos.y - activeGlass.pos.y);
        dx = Math.max(0, dx - gSpineW);
        dy = Math.max(0, dy - gSpineH);
        const isInside = Math.sqrt(dx * dx + dy * dy) <= gCorner;

        if (isPinnedRef.current) {
          // Dynamic glow following finger
          clickGlowRef.current.active = true;
          clickGlowRef.current.isHolding = true; // Stay glowing even if pulled outside
          clickGlowRef.current.offset = {
            x: pos.x - activeGlass.pos.x,
            y: pos.y - activeGlass.pos.y,
          };
          clickGlowRef.current.absPos = { x: pos.x, y: pos.y };
          activeGlass.targetClickScale = isInside ? 1.08 : 1.03; // Slight shrink when pulled far outside

          // Keep overall movement range very small, relying primarily on local surface deformation
          if (activeGlass.anchorPos && (clickGlowRef.current as any).initialPos) {
            const pullDx = pos.x - (clickGlowRef.current as any).initialPos.x;
            const pullDy = pos.y - (clickGlowRef.current as any).initialPos.y;
            activeGlass.targetPos = {
              x: activeGlass.anchorPos.x + pullDx * 0.12,
              y: activeGlass.anchorPos.y + pullDy * 0.12
            };
          }

          startAnimation();
          return;
        } else if (activeGlass.isDragging) {
          const margin = 20;
          const newX = Math.max(margin, Math.min(window.innerWidth - margin, pos.x - activeGlass.dragOffset.x));
          const newY = Math.max(margin, Math.min(window.innerHeight - margin, pos.y - activeGlass.dragOffset.y));

          activeGlass.targetPos = { x: newX, y: newY };
          startAnimation();
          return;
        }
      }

      if (!activeGlass || !activeGlass.isDragging) {
        if (!('touches' in e)) {
          let hovering = false;
          for (let i = glassesRef.current.length - 1; i >= 0; i--) {
            const glass = glassesRef.current[i];
            const { corner: gCorner, spineW: gSpineW, spineH: gSpineH } = getGlassBounds(glass);
            let dx = Math.abs(pos.x - glass.pos.x);
            let dy = Math.abs(pos.y - glass.pos.y);
            dx = Math.max(0, dx - gSpineW);
            dy = Math.max(0, dy - gSpineH);

            if (Math.sqrt(dx * dx + dy * dy) <= gCorner) {
              hovering = true;
              break;
            }
          }
          canvas.style.cursor = hovering ? (isPinnedRef.current ? 'crosshair' : 'grab') : 'default';
        }
        return;
      }
    };

    const handleUp = () => {
      for (const g of glassesRef.current) {
        g.isDragging = false;
        g.targetClickScale = 1.0;
        if (isPinnedRef.current && g.anchorPos) {
          // Snap back to anchor elastically
          g.targetPos = { x: g.anchorPos.x, y: g.anchorPos.y };
        }
      }
      activeGlassId.current = null;
      canvas.style.cursor = isPinnedRef.current ? 'crosshair' : 'default';

      // Smoothly fade out glow on release
      clickGlowRef.current.isHolding = false;

      startAnimation();
    };

    canvas.addEventListener('mousedown', handleDown);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    canvas.addEventListener('touchstart', handleDown, { passive: false });
    window.addEventListener('touchmove', handleMove, { passive: false });
    window.addEventListener('touchend', handleUp);
    window.addEventListener('touchcancel', handleUp);

    return () => {
      canvas.removeEventListener('mousedown', handleDown);
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
      canvas.removeEventListener('touchstart', handleDown);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleUp);
      window.removeEventListener('touchcancel', handleUp);
    };
  }, [getShapeBounds, renderFrame]);

  // Device Orientation / Gyroscope Motion Listener (Calibrated to initial holding baseline)
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.gamma === null || e.beta === null) return;
      gyroRef.current.hasGyro = true;

      // Initialize resting baseline posture on first reading
      if (gyroRef.current.baseBeta === null || gyroRef.current.baseGamma === null) {
        gyroRef.current.baseBeta = e.beta;
        gyroRef.current.baseGamma = e.gamma;
      }

      // Calculate relative delta against the initial startup baseline
      const deltaGamma = e.gamma - (gyroRef.current.baseGamma ?? e.gamma);
      const deltaBeta = e.beta - (gyroRef.current.baseBeta ?? e.beta);

      // Normalized relative tilt with generous organic dynamic range
      const normX = Math.max(-2.0, Math.min(2.0, deltaGamma / 25.0));
      const normY = Math.max(-2.0, Math.min(2.0, deltaBeta / 25.0));

      gyroRef.current.tiltX = normX;
      gyroRef.current.tiltY = normY;

      // Highlighting: dynamic light angle shift
      gyroRef.current.highlightAngleOffset = normX * 45.0 + normY * 25.0;

      startAnimRef.current?.();
    };

    window.addEventListener('deviceorientation', handleOrientation, true);
    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, []);

  // Actions for glass drops (adds 3 at a time: capsule + rounded_rect + circle)
  const handleAddGlass = () => {
    if (glassesRef.current.length + 3 > 12) return;
    const cx = window.innerWidth / 2 + (Math.random() - 0.5) * 60;
    const cy = window.innerHeight / 2 + (Math.random() - 0.5) * 60;
    const newSet: GlassItem[] = [
      {
        id: nextGlassId.current++,
        shapeType: 'capsule',
        rectW: 280,
        rectH: 110,
        cornerRadius: 55,
        pos: { x: cx - 260, y: cy },
        targetPos: { x: cx - 260, y: cy },
        velocity: { x: (Math.random() - 0.5) * 8, y: (Math.random() - 0.5) * 8 },
        clickScale: 0.75,
        targetClickScale: 1.0,
        clickScaleVel: 0.05,
        isDragging: false,
        dragOffset: { x: 0, y: 0 },
        whiteness: 0.0,
      },
      {
        id: nextGlassId.current++,
        shapeType: 'rounded_rect',
        rectW: 240,
        rectH: 160,
        cornerRadius: 36,
        pos: { x: cx, y: cy },
        targetPos: { x: cx, y: cy },
        velocity: { x: (Math.random() - 0.5) * 8, y: (Math.random() - 0.5) * 8 },
        clickScale: 0.75,
        targetClickScale: 1.0,
        clickScaleVel: 0.05,
        isDragging: false,
        dragOffset: { x: 0, y: 0 },
        whiteness: 0.0,
      },
      {
        id: nextGlassId.current++,
        shapeType: 'circle',
        rectW: 150,
        rectH: 150,
        cornerRadius: 75,
        size: 75,
        pos: { x: cx + 260, y: cy },
        targetPos: { x: cx + 260, y: cy },
        velocity: { x: (Math.random() - 0.5) * 8, y: (Math.random() - 0.5) * 8 },
        clickScale: 0.75,
        targetClickScale: 1.0,
        clickScaleVel: 0.05,
        isDragging: false,
        dragOffset: { x: 0, y: 0 },
        whiteness: 0.0,
      },
    ];
    glassesRef.current.push(...newSet);
    setGlassCount(glassesRef.current.length);
    requestRender();
    startAnimRef.current?.();
  };

  const handleResetGlasses = () => {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    const count = glassesRef.current.length;
    const rows = Math.ceil(count / 3);
    glassesRef.current.forEach((g, idx) => {
      const col = idx % 3;
      const row = Math.floor(idx / 3);
      const colOffset = (col - 1) * 280;
      const rowOffset = (row - (rows - 1) / 2) * 180;
      g.targetPos = { x: cx + colOffset, y: cy + rowOffset };
    });
    requestRender();
    startAnimRef.current?.();
  };

  const handleClearExtras = () => {
    if (glassesRef.current.length <= 3) return;
    glassesRef.current = glassesRef.current.slice(0, 3);
    setGlassCount(3);
    requestRender();
    startAnimRef.current?.();
  };

  // Drag & drop file to window
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');

    if (!isImage && !isVideo) return;

    const objectUrl = URL.createObjectURL(file);
    setConfig((prev) => ({
      ...prev,
      bg: {
        type: isVideo ? 'video' : 'image',
        src: objectUrl,
        blur: prev.bg.blur ?? 0,
      },
    }));
  };

  return (
    <div
      className="w-screen h-screen overflow-hidden bg-black font-sans relative select-none"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Background Media */}
      {config.bg.type === 'image' && config.bg.src && (
        <img
          ref={imgRef}
          src={config.bg.src}
          crossOrigin={config.bg.src.startsWith('http') ? 'anonymous' : undefined}
          alt="Background"
          className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none transition-[filter] duration-100"
          style={{
            filter: (config.bg.blur ?? 0) > 0 ? `blur(${config.bg.blur}px)` : undefined,
          }}
          onLoad={handleImageLoad}
        />
      )}
      {config.bg.type === 'video' && config.bg.src && (
        <video
          ref={videoRef}
          src={config.bg.src}
          crossOrigin={config.bg.src.startsWith('http') ? 'anonymous' : undefined}
          className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none transition-[filter] duration-100"
          style={{
            filter: (config.bg.blur ?? 0) > 0 ? `blur(${config.bg.blur}px)` : undefined,
          }}
          loop
          muted
          playsInline
          onLoadedMetadata={handleVideoLoad}
          onPlay={requestRender}
        />
      )}
      {/* WebGL Canvas */}
      <canvas id="glass-canvas" ref={canvasRef} className="absolute inset-0 z-10 w-full h-full block touch-none" />

      {/* Top Glass Mode Switcher Pill */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-40 flex items-center p-1 rounded-full bg-black/40 backdrop-blur-2xl border border-white/20 shadow-[0_12px_40px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(255,255,255,0.3)] select-none">
        <button
          onClick={() => setViewMode('canvas')}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium tracking-wide bg-white text-neutral-900 shadow-[0_2px_10px_rgba(0,0,0,0.2)] font-semibold"
        >
          <span>🔮</span>
          <span>物理流体画布 (G2 胶囊)</span>
        </button>
      </div>

      {/* Drag & Drop Overlay */}
      {isDragOver && (
        <div className="absolute inset-0 z-40 bg-black/70 backdrop-blur-md border-2 border-dashed border-emerald-400 flex flex-col items-center justify-center pointer-events-none text-white animate-in fade-in">
          <p className="text-xl font-medium tracking-wide">松开即可更换背景图片 / 视频</p>
          <p className="text-sm text-neutral-400 mt-1">支持 PNG, JPG, WebP, MP4, WebM</p>
        </div>
      )}

      {/* Left Docked Control Sidebar */}
      <LeftSidebar
        config={config}
        onChangeConfig={(newCfg) => setConfig(newCfg)}
        glassCount={glassCount}
        maxGlasses={12}
        isPinned={isPinned}
        onTogglePin={() => setIsPinned((prev) => !prev)}
        onAddGlass={handleAddGlass}
        onResetGlasses={handleResetGlasses}
        onClearExtras={handleClearExtras}
        bgLuminance={bgLuminance}
      />
    </div>
  );
}
