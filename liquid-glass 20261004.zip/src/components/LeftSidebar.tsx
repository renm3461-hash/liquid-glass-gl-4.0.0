import React, { useState, useRef } from 'react';
import {
  Shapes,
  Image as ImageIcon,
  Sparkles,
  Sliders,
  Palette,
  Sun,
  Moon,
  Plus,
  RotateCcw,
  Pin,
  PinOff,
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  Upload,
  Link as LinkIcon,
  Download,
  PlaySquare,
  RotateCw,
} from 'lucide-react';
import { GlassConfig, defaultGlassConfig } from '../config';
import {
  SliderRow,
  AngleControl,
  SectionCard,
  ToggleRow,
} from './ControlWidgets';
import {
  IMAGE_PRESETS,
  CATEGORIES,
} from '../data/backgroundPresets';
import { generateFlawlessCapsule } from '../utils/capsuleGeometry';

interface LeftSidebarProps {
  config: GlassConfig;
  onChangeConfig: (newConfig: GlassConfig) => void;
  glassCount: number;
  maxGlasses: number;
  isPinned: boolean;
  onTogglePin: () => void;
  onAddGlass: () => void;
  onResetGlasses: () => void;
  onClearExtras: () => void;
  bgLuminance?: number;
}

type TabType = 'shape' | 'bg' | 'optics' | 'color' | 'light' | 'shadow' | 'anim';

export default function LeftSidebar({
  config,
  onChangeConfig,
  glassCount,
  maxGlasses,
  isPinned,
  onTogglePin,
  onAddGlass,
  onResetGlasses,
  onClearExtras,
  bgLuminance = 0.5,
}: LeftSidebarProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>('shape');
  const [bgCategory, setBgCategory] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [capsuleCopied, setCapsuleCopied] = useState(false);
  const [capsuleAngle, setCapsuleAngle] = useState(55);
  const [customUrl, setCustomUrl] = useState('');
  const [superellipseStyle, setSuperellipseStyle] = useState<'standard' | 'full' | 'gentle'>('standard');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [animState, setAnimState] = useState({
    fromShape: 'circle',
    toShape: 'rounded_rect',
    duration: 1.5,
    autoLoop: false,
    isPlaying: false,
  });
  const animRef = useRef({ cancel: false });
  const morphRef = useRef<{ cancel: boolean }>({ cancel: false });

  const SHAPE_PRESETS: Record<string, { type: 'circle' | 'capsule' | 'rounded_rect'; size: number; rectW: number; rectH: number; cornerRadius: number }> = {
    circle: { type: 'circle', size: 85, rectW: 170, rectH: 170, cornerRadius: 85 },
    capsule: { type: 'capsule', size: 60, rectW: 320, rectH: 120, cornerRadius: 60 },
    rounded_rect: { type: 'rounded_rect', size: 0, rectW: 340, rectH: 160, cornerRadius: 38 },
    pill_small: { type: 'capsule', size: 0, rectW: 220, rectH: 90, cornerRadius: 45 },
    square_rounded: { type: 'rounded_rect', size: 0, rectW: 200, rectH: 200, cornerRadius: 45 },
  };

  const updateShape = (partial: Partial<GlassConfig['shape']>) => {
    onChangeConfig({ ...config, shape: { ...config.shape, ...partial } });
  };
  const updateColor = (partial: Partial<GlassConfig['color']>) => {
    onChangeConfig({ ...config, color: { ...config.color, ...partial } });
  };
  const updateOptics = (partial: Partial<GlassConfig['optics']>) => {
    onChangeConfig({ ...config, optics: { ...config.optics, ...partial } });
  };
  const updateHighlight = (partial: Partial<GlassConfig['highlight']>) => {
    onChangeConfig({ ...config, highlight: { ...config.highlight, ...partial } });
  };
  const updateOuterShadow = (partial: Partial<GlassConfig['outerShadow']>) => {
    onChangeConfig({ ...config, outerShadow: { ...config.outerShadow, ...partial } });
  };
  const updateInnerShadow = (partial: Partial<GlassConfig['innerShadow']>) => {
    onChangeConfig({ ...config, innerShadow: { ...config.innerShadow, ...partial } });
  };

  const calculateAdaptedCorner = (
    type: string,
    w: number,
    h: number,
    style: 'standard' | 'full' | 'gentle' = superellipseStyle
  ): number => {
    const maxR = Math.min(w, h) / 2;
    if (type === 'circle') return Math.round(config.shape.size || 85);
    if (type === 'capsule') return Math.round(maxR);
    const aspect = Math.max(w, h) / Math.min(w, h);
    let baseFactor = 0.38;
    if (style === 'full') baseFactor = 0.44;
    else if (style === 'gentle') baseFactor = 0.28;
    const factor = Math.min(0.48, baseFactor / Math.pow(aspect, 0.20));
    return Math.round(Math.min(w, h) * factor);
  };

  const animateMorphTo = (
    target: { type?: 'circle' | 'capsule' | 'rounded_rect'; rectW?: number; rectH?: number; size?: number; cornerRadius?: number },
    durationMs: number = 220
  ) => {
    morphRef.current.cancel = true;
    const curAnim = { cancel: false };
    morphRef.current = curAnim;

    const startType = config.shape.type;
    const targetType = target.type || startType;
    const startW = startType === 'circle' ? (config.shape.size || 85) * 2 : (config.shape.rectW || 340);
    const startH = startType === 'circle' ? (config.shape.size || 85) * 2 : (config.shape.rectH || 160);
    const startR = startType === 'capsule'
      ? Math.min(startW, startH) / 2
      : (startType === 'circle' ? (config.shape.size || 85) : config.shape.cornerRadius);

    let targetW = target.rectW || 340;
    let targetH = target.rectH || (targetType === 'capsule' ? 150 : 160);
    let targetR = target.cornerRadius;
    let targetSize = target.size || 85;

    if (targetType === 'circle') {
      targetW = targetSize * 2;
      targetH = targetSize * 2;
      targetR = targetSize;
    } else if (targetType === 'capsule') {
      targetR = Math.min(targetW, targetH) / 2;
    } else if (targetR === undefined) {
      targetR = calculateAdaptedCorner('rounded_rect', targetW, targetH, superellipseStyle);
    }

    const startTime = performance.now();
    const transitionPair = `${startType}->${targetType}`;
    const fluidBounce = (t: number) => (t <= 0 ? 0 : t >= 1 ? 1 : (t - 1) * (t - 1) * (2.35 * (t - 1) + 1.35) + 1);

    const frame = (now: number) => {
      if (curAnim.cancel) return;
      let progress = Math.min(1, (now - startTime) / durationMs);
      const eased = fluidBounce(progress);
      const curW = Math.round(startW + (targetW - startW) * eased);
      const curH = Math.round(startH + (targetH - startH) * eased);
      const maxPossibleR = Math.min(curW, curH) / 2;

      let curR = startR;
      let curType: 'circle' | 'capsule' | 'rounded_rect' = targetType;

      switch (transitionPair) {
        case 'circle->capsule':
          curType = 'capsule';
          curR = Math.round(maxPossibleR);
          break;
        case 'circle->rounded_rect': {
          curType = 'rounded_rect';
          const rawR = (startW / 2) + (targetR - (startW / 2)) * eased;
          curR = Math.round(Math.min(maxPossibleR, Math.max(2, rawR)));
          break;
        }
        case 'capsule->circle':
          curType = progress < 1 ? 'capsule' : 'circle';
          curR = Math.round(maxPossibleR);
          break;
        case 'capsule->rounded_rect': {
          curType = 'rounded_rect';
          const initCorner = Math.min(startW, startH) / 2;
          const rawR = initCorner + (targetR - initCorner) * eased;
          curR = Math.round(Math.min(maxPossibleR, Math.max(2, rawR)));
          break;
        }
        case 'rounded_rect->circle': {
          curType = progress < 1 ? 'rounded_rect' : 'circle';
          const rawR = startR + (targetR - startR) * eased;
          curR = Math.round(Math.min(maxPossibleR, Math.max(2, rawR)));
          break;
        }
        case 'rounded_rect->capsule': {
          curType = progress < 1 ? 'rounded_rect' : 'capsule';
          const rawR = startR + (Math.min(targetW, targetH) / 2 - startR) * eased;
          curR = Math.round(Math.min(maxPossibleR, Math.max(2, rawR)));
          break;
        }
        default: {
          curType = targetType;
          const rawR = startR + (targetR - startR) * eased;
          curR = Math.round(Math.min(maxPossibleR, Math.max(2, rawR)));
          break;
        }
      }

      updateShape({
        type: curType,
        rectW: curW,
        rectH: curH,
        cornerRadius: curR,
        size: Math.round(curW / 2),
      });

      if (progress < 1) {
        requestAnimationFrame(frame);
      } else {
        updateShape({
          type: targetType,
          rectW: targetW,
          rectH: targetH,
          cornerRadius: targetR,
          size: targetType === 'circle' ? targetSize : Math.round(targetW / 2),
        });
      }
    };
    requestAnimationFrame(frame);
  };

  const applySuperellipseStyle = (
    targetStyle: 'standard' | 'full' | 'gentle',
    overrideType?: string,
    overrideW?: number,
    overrideH?: number
  ) => {
    setSuperellipseStyle(targetStyle);
    const shapeType = overrideType || config.shape.type;
    const w = overrideW || config.shape.rectW;
    const h = overrideH || config.shape.rectH;
    const newR = calculateAdaptedCorner(shapeType, w, h, targetStyle);
    animateMorphTo({ type: shapeType as any, rectW: w, rectH: h, cornerRadius: newR }, 220);
  };

  const playAnimation = (overrideFrom?: string, overrideTo?: string) => {
    const fromKey = overrideFrom || animState.fromShape;
    const toKey = overrideTo || animState.toShape;
    animRef.current.cancel = false;
    setAnimState((prev) => ({ ...prev, fromShape: fromKey, toShape: toKey, isPlaying: true }));

    const fromConfig = SHAPE_PRESETS[fromKey] || SHAPE_PRESETS.circle;
    const toConfig = SHAPE_PRESETS[toKey] || SHAPE_PRESETS.rounded_rect;

    updateShape({
      type: fromConfig.type,
      rectW: fromConfig.rectW,
      rectH: fromConfig.rectH,
      size: fromConfig.size,
      cornerRadius: fromConfig.cornerRadius,
    });

    const durationMs = 220;
    setTimeout(() => {
      animateMorphTo({
        type: toConfig.type,
        rectW: toConfig.rectW,
        rectH: toConfig.rectH,
        size: toConfig.size,
        cornerRadius: toConfig.cornerRadius,
      }, durationMs);

      if (!animState.autoLoop) {
        setTimeout(() => setAnimState((prev) => ({ ...prev, isPlaying: false })), durationMs + 30);
      }
    }, 30);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    if (!isImage && !isVideo) {
      alert('请上传图片 (JPG, PNG, WebP) 或视频 (MP4, WebM) 文件');
      return;
    }
    onChangeConfig({
      ...config,
      bg: { type: isVideo ? 'video' : 'image', src: URL.createObjectURL(file), blur: config.bg.blur ?? 0 },
    });
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customUrl.trim()) return;
    const isVideo = /\.(mp4|webm|mov)(\?.*)?$/i.test(customUrl);
    onChangeConfig({
      ...config,
      bg: { type: isVideo ? 'video' : 'image', src: customUrl.trim(), blur: config.bg.blur ?? 0 },
    });
    setCustomUrl('');
  };

  const setPureBlackBg = () => {
    onChangeConfig({ ...config, bg: { type: 'image', src: '', blur: config.bg.blur ?? 0 } });
  };

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(JSON.stringify(config, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadHTML = async () => {
    try {
      const res = await fetch('/liquid-glass.html');
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'liquid-glass.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } else {
        alert('离线 HTML 尚未准备好，请稍后重试。');
      }
    } catch {
      alert('下载离线 HTML 失败：请稍后重试。');
    }
  };

  const navItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'shape', label: '形状', icon: <Shapes className="w-4 h-4 text-emerald-400" /> },
    { id: 'bg', label: '壁纸', icon: <ImageIcon className="w-4 h-4 text-cyan-400" /> },
    { id: 'optics', label: '光学', icon: <Sliders className="w-4 h-4 text-amber-400" /> },
    { id: 'color', label: '色彩', icon: <Palette className="w-4 h-4 text-purple-400" /> },
    { id: 'light', label: '高光', icon: <Sun className="w-4 h-4 text-yellow-300" /> },
    { id: 'shadow', label: '阴影', icon: <Moon className="w-4 h-4 text-blue-400" /> },
    { id: 'anim', label: '形变', icon: <PlaySquare className="w-4 h-4 text-emerald-300" /> },
  ];

  return (
    <>
      {/* 侧边栏展开/折叠浮动触发按钮 (当侧边栏折叠时显示) */}
      {!isOpen && (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="fixed left-4 top-4 z-40 p-2.5 rounded-2xl bg-neutral-900/90 hover:bg-neutral-800 text-white border border-white/15 shadow-2xl backdrop-blur-xl flex items-center gap-2 text-xs font-semibold transition active:scale-95 group"
          title="展开调节侧边栏"
        >
          <Sparkles className="w-4 h-4 text-emerald-400 group-hover:rotate-12 transition-transform" />
          <span>调节控制面板</span>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>
      )}

      {/* 左侧抽屉控制面板 (Left Sidebar Panel) */}
      <aside
        className={`fixed left-0 top-0 bottom-0 z-40 w-[380px] max-w-[90vw] bg-neutral-950/90 backdrop-blur-2xl border-r border-white/10 shadow-[8px_0_32px_rgba(0,0,0,0.7)] flex flex-col transition-transform duration-300 ease-out select-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* 顶部标题栏 */}
        <div className="p-4 pb-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-400 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Sparkles className="w-4.5 h-4.5 text-black" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                Liquid Glass Studio
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  v3.8
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400">物理级实时液态玻璃渲染器</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onTogglePin}
              className={`p-1.5 rounded-xl border text-xs transition ${
                isPinned
                  ? 'bg-amber-400/20 border-amber-400 text-amber-300'
                  : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
              }`}
              title={isPinned ? '已锁定位置 (点击解锁自由拖动)' : '自由拖动模式 (点击锁定位置)'}
            >
              {isPinned ? <Pin className="w-3.5 h-3.5" /> : <PinOff className="w-3.5 h-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-400 hover:text-white transition"
              title="收起侧边栏"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 玻璃多球管理与快捷操作条 */}
        <div className="px-4 py-2 bg-neutral-900/50 border-b border-white/5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400 text-[11px]">玻璃数量:</span>
            <span className="font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20 text-[11px]">
              {glassCount} / {maxGlasses}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onAddGlass}
              disabled={glassCount >= maxGlasses}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 text-[11px] font-semibold disabled:opacity-40 transition flex items-center gap-1 active:scale-95 shadow-sm"
              title="一次添加 3 个玻璃 (胶囊型 + 圆角矩形 + 圆形)"
            >
              <Plus className="w-3 h-3" />
              <span>添加一组 (+3)</span>
            </button>
            {glassCount > 3 && (
              <button
                type="button"
                onClick={onClearExtras}
                className="px-2 py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-400/40 text-red-300 text-[11px] font-medium transition active:scale-95"
                title="清除多余玻璃，保留默认 3 个玻璃"
              >
                清理多余
              </button>
            )}
            <button
              type="button"
              onClick={onResetGlasses}
              className="p-1 text-neutral-400 hover:text-white rounded-lg transition hover:bg-white/5"
              title="重置玻璃位置 (居中整齐排列)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 顶部标签切换栏 (Tab Bar) */}
        <div className="p-2 border-b border-white/10 bg-neutral-900/30">
          <div className="grid grid-cols-7 gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`py-2 flex flex-col items-center justify-center rounded-xl transition text-[10px] font-medium gap-1 ${
                  activeTab === item.id
                    ? 'bg-white/15 text-white border border-white/20 shadow-md font-semibold'
                    : 'text-neutral-400 hover:text-white hover:bg-white/5'
                }`}
                title={item.label}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 中间可滚动面板内容区域 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-white/10 hover:scrollbar-thumb-white/20">
          {/* TAB 1: 形状 (Shape) */}
          {activeTab === 'shape' && (
            <div className="space-y-4">
              {/* 预设几何形态切换 */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2">
                <span className="text-xs font-semibold text-neutral-300 block">基础形态预设</span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {[
                    { id: 'circle', label: '正圆', icon: '⭕' },
                    { id: 'capsule', label: '胶囊形', icon: '💊' },
                    { id: 'rounded_rect', label: '超椭圆', icon: '🔲' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        const target = SHAPE_PRESETS[s.id];
                        animateMorphTo(target, 220);
                      }}
                      className={`py-2 px-2.5 rounded-xl border font-medium text-center transition active:scale-95 flex items-center justify-center gap-1.5 ${
                        config.shape.type === s.id
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-semibold shadow-sm'
                          : 'bg-white/5 border-white/10 text-neutral-300 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <span>{s.icon}</span>
                      <span>{s.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 尺寸滑块调节 */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-3">
                {config.shape.type === 'circle' && (
                  <SliderRow
                    id="slider-shape-size"
                    label="正圆半径 (Radius)"
                    value={config.shape.size}
                    min={40}
                    max={250}
                    unit="px"
                    onChange={(v) => updateShape({ size: v })}
                    presets={[
                      { label: '小 60px', val: 60 },
                      { label: '标准 85px', val: 85, isDefault: true },
                      { label: '大 130px', val: 130 },
                    ]}
                  />
                )}

                {config.shape.type !== 'circle' && (
                  <>
                    <SliderRow
                      id="slider-shape-width"
                      label="玻璃宽度 (Width)"
                      value={config.shape.rectW}
                      min={80}
                      max={600}
                      unit="px"
                      onChange={(w) => {
                        const autoR = calculateAdaptedCorner(config.shape.type, w, config.shape.rectH);
                        updateShape({ rectW: w, cornerRadius: autoR });
                      }}
                    />

                    <SliderRow
                      id="slider-shape-height"
                      label="玻璃高度 (Height)"
                      value={config.shape.rectH}
                      min={60}
                      max={400}
                      unit="px"
                      onChange={(h) => {
                        const autoR = calculateAdaptedCorner(config.shape.type, config.shape.rectW, h);
                        updateShape({ rectH: h, cornerRadius: autoR });
                      }}
                    />

                    {config.shape.type === 'rounded_rect' && (
                      <SliderRow
                        id="slider-shape-radius"
                        label="圆角半径 (Corner Radius)"
                        value={config.shape.cornerRadius}
                        min={0}
                        max={Math.floor(Math.min(config.shape.rectW, config.shape.rectH) / 2)}
                        unit="px"
                        onChange={(r) => updateShape({ cornerRadius: r })}
                      />
                    )}
                  </>
                )}
              </div>

              {/* G2 超平滑胶囊几何参数与 Path 复制 */}
              {config.shape.type === 'capsule' && (() => {
                const capsuleRes = generateFlawlessCapsule(config.shape.rectW, config.shape.rectH, capsuleAngle);
                return (
                  <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-emerald-400">
                        {capsuleRes.isVertical ? 'G2 竖向超平滑胶囊' : 'G2 横向超平滑胶囊'}
                      </span>
                      <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md ${
                        capsuleRes.isTooCloseToSquare ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {capsuleRes.isTooCloseToSquare ? '正圆防护状态' : `生效角度: ${capsuleRes.actualAngle.toFixed(1)}°`}
                      </span>
                    </div>

                    {capsuleRes.isTooCloseToSquare && (
                      <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-200 leading-relaxed space-y-1.5">
                        <p className="font-semibold text-amber-300 flex items-center gap-1">
                          💡 形状使用建议：
                        </p>
                        <p>
                          当前宽高非常接近（|W - H| &lt; 12px）。当宽高靠近正方形时，不推荐强制使用胶囊型；建议切换为<b>正圆</b>或<b>超椭圆</b>以获得最佳拟真形态。
                        </p>
                        <p className="text-[10px] text-amber-300/80 italic">
                          *在允许使用胶囊的最大限度内，系统将尽量使用本超平滑胶囊图形。
                        </p>
                      </div>
                    )}

                    <SliderRow
                      id="slider-capsule-angle"
                      label="接管角度 (Takeover Angle)"
                      value={capsuleAngle}
                      min={0}
                      max={60}
                      step={1}
                      unit="°"
                      accent="emerald"
                      onChange={(v) => setCapsuleAngle(v)}
                      presets={[
                        { label: '30°', val: 30 },
                        { label: '45°', val: 45 },
                        { label: '55° (默认)', val: 55, isDefault: true },
                        { label: '60°', val: 60 },
                      ]}
                    />
                    <div className="space-y-1.5">
                      <div className="p-2 rounded-lg bg-black/40 border border-white/10 font-mono text-[10px] text-neutral-400 break-all max-h-20 overflow-y-auto scrollbar-thin">
                        clip-path: {capsuleRes.clipPathCss};
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(`clip-path: ${capsuleRes.clipPathCss};`);
                          setCapsuleCopied(true);
                          setTimeout(() => setCapsuleCopied(false), 2000);
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-black font-semibold text-xs transition active:scale-95 shadow-md flex items-center justify-center gap-1.5"
                      >
                        {capsuleCopied ? '已复制 G2 完美胶囊 Path！' : '复制胶囊 clip-path (CSS)'}
                      </button>
                    </div>
                  </div>
                );
              })()}

              {/* 苹果超椭圆曲率预设 */}
              {config.shape.type === 'rounded_rect' && (
                <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2">
                  <span className="text-xs font-semibold text-neutral-300 block">超椭圆曲率风格</span>
                  <div className="grid grid-cols-3 gap-1.5 text-xs">
                    {[
                      { id: 'standard', label: '标准 G2' },
                      { id: 'full', label: '饱满大圆角' },
                      { id: 'gentle', label: '微圆角' },
                    ].map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => applySuperellipseStyle(st.id as any)}
                        className={`py-1.5 px-2 rounded-xl text-xs font-medium transition ${
                          superellipseStyle === st.id
                            ? 'bg-emerald-400 text-black font-semibold'
                            : 'bg-white/5 border border-white/10 text-neutral-300 hover:text-white'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: 背景 (Background - 24张精选大片壁纸) */}
          {activeTab === 'bg' && (
            <div className="space-y-3.5">
              {/* 纯黑背景切换 */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-900/80 border border-white/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-6 h-6 rounded-full bg-black border border-white/30 shadow-inner" />
                  <div>
                    <span className="text-xs font-semibold text-white block">极简纯黑背景</span>
                    <span className="text-[10px] text-neutral-400">凸显纯粹高透折射与光影层次</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={setPureBlackBg}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition ${
                    config.bg.type === 'image' && !config.bg.src
                      ? 'bg-white text-black font-semibold'
                      : 'bg-white/10 text-neutral-300 hover:text-white'
                  }`}
                >
                  {config.bg.type === 'image' && !config.bg.src ? '使用中' : '设为纯黑'}
                </button>
              </div>

              {/* 24张精选大片壁纸分类 */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">精选高清大片壁纸 (24张)</span>
                </div>

                {/* 分类筛选 */}
                <div className="flex gap-1.5 text-xs">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setBgCategory(cat.id)}
                      className={`flex-1 py-1.5 px-2 rounded-xl text-center font-medium transition active:scale-98 text-[11px] ${
                        bgCategory === cat.id
                          ? 'bg-emerald-400 text-black font-semibold shadow-sm'
                          : 'bg-neutral-800/80 text-neutral-300 hover:text-white hover:bg-neutral-700'
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>

                {/* 缩略图网格 */}
                <div className="max-h-72 overflow-y-auto pr-1 space-y-1.5 rounded-xl">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {IMAGE_PRESETS.filter((img) => bgCategory === 'all' || img.category === bgCategory).map((wp) => {
                      const isActive = config.bg.type === 'image' && config.bg.src === wp.url;
                      return (
                        <button
                          key={wp.id}
                          type="button"
                          onClick={() => onChangeConfig({ ...config, bg: { type: 'image', src: wp.url, blur: config.bg.blur ?? 0 } })}
                          className={`group relative overflow-hidden rounded-xl border text-left transition active:scale-98 ${
                            isActive
                              ? 'border-emerald-400 ring-2 ring-emerald-400/40 shadow-lg'
                              : 'border-white/10 hover:border-white/30'
                          }`}
                        >
                          <div className="h-20 w-full relative bg-neutral-900 overflow-hidden">
                            <img
                              src={wp.thumb}
                              alt={wp.name}
                              className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                              loading="lazy"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                            {isActive && (
                              <span className="absolute top-1.5 right-1.5 text-[9px] px-1.5 py-0.5 bg-emerald-400 text-black rounded font-bold shadow">
                                使用中
                              </span>
                            )}
                            <span className="absolute top-1.5 left-1.5 text-[9px] px-1.5 py-0.5 bg-black/60 backdrop-blur rounded text-neutral-300 font-mono">
                              {wp.categoryName}
                            </span>
                          </div>
                          <div className="p-2 bg-neutral-900/95 space-y-0.5">
                            <span className="text-[11px] font-medium text-white block truncate">{wp.name}</span>
                            <span className="text-[9px] text-neutral-400 line-clamp-1 block">{wp.desc}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 上传与自定义 URL */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2.5">
                <span className="text-xs font-semibold text-neutral-300 block">自定义素材</span>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,video/mp4,video/webm"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-neutral-800/80 hover:bg-neutral-800 active:scale-98 border border-dashed border-white/25 rounded-xl text-xs font-medium text-neutral-200 hover:text-white transition"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-400" />
                  <span>上传本地图片 / 视频 (PNG, JPG, MP4, WebM)</span>
                </button>

                <form onSubmit={handleUrlSubmit} className="flex gap-2">
                  <div className="relative flex-1">
                    <LinkIcon className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="url"
                      value={customUrl}
                      onChange={(e) => setCustomUrl(e.target.value)}
                      placeholder="或粘贴线上图片/视频 URL..."
                      className="w-full bg-neutral-800/80 border border-white/15 pl-8 pr-3 py-1.5 rounded-xl text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-white"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!customUrl.trim()}
                    className="px-3 py-1.5 bg-white/15 hover:bg-white/25 disabled:opacity-40 rounded-xl text-xs font-medium transition"
                  >
                    应用
                  </button>
                </form>
              </div>

              {/* 背景模糊 */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2">
                <SliderRow
                  id="slider-bg-blur"
                  label="背景虚化模糊 (Background Blur)"
                  value={config.bg.blur ?? 0}
                  min={0}
                  max={10}
                  step={0.5}
                  unit="px"
                  onChange={(v) => onChangeConfig({ ...config, bg: { ...config.bg, blur: v } })}
                  presets={[
                    { label: '0px (清晰)', val: 0, isDefault: true },
                    { label: '2px', val: 2 },
                    { label: '5px', val: 5 },
                    { label: '10px (上限)', val: 10 },
                  ]}
                />
              </div>
            </div>
          )}

          {/* TAB 3: 光学 (Optics) */}
          {activeTab === 'optics' && (
            <div className="space-y-3.5">
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-3">
                <SliderRow
                  id="slider-optics-refraction"
                  label="折射强度 (Refraction IOR)"
                  value={config.optics.refraction}
                  min={0}
                  max={200}
                  onChange={(v) => updateOptics({ refraction: v })}
                  presets={[
                    { label: '平透 0', val: 0 },
                    { label: '标准 100', val: 100, isDefault: true },
                    { label: '强折射 180', val: 180 },
                  ]}
                />

                <SliderRow
                  id="slider-optics-edge"
                  label="边缘曲率宽度 (Edge Bevel Width)"
                  value={config.optics.edgeWidth}
                  min={0}
                  max={100}
                  onChange={(v) => updateOptics({ edgeWidth: v })}
                />

                <SliderRow
                  id="slider-optics-dispersion"
                  label="色散棱镜彩虹效果 (Chromatic Aberration)"
                  value={config.optics.dispersion}
                  min={0}
                  max={100}
                  onChange={(v) => updateOptics({ dispersion: v })}
                />

                <SliderRow
                  id="slider-optics-blur"
                  label="玻璃内部磨砂模糊 (Frosted Blur)"
                  value={config.optics.blurRadius}
                  min={0}
                  max={10}
                  step={0.5}
                  unit="px"
                  onChange={(v) => updateOptics({ blurRadius: v })}
                />

                <SliderRow
                  id="slider-optics-liquid"
                  label="液态流体融合桥接 (Liquid Bridge)"
                  value={config.optics.liquidBridge}
                  min={0}
                  max={50}
                  onChange={(v) => updateOptics({ liquidBridge: v })}
                />

                <SliderRow
                  id="slider-optics-fluid"
                  label="高速移动动态流体形变 (Fluid Deformation)"
                  value={config.optics.fluidIntensity}
                  min={0}
                  max={100}
                  onChange={(v) => updateOptics({ fluidIntensity: v })}
                />
              </div>
            </div>
          )}

          {/* TAB 4: 色彩 (Color) */}
          {activeTab === 'color' && (
            <div className="space-y-3.5">
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-3">
                {/* 随背景明暗自适应调节不透明度开关 (默认打开) */}
                <ToggleRow
                  id="toggle-adaptive-opacity"
                  label="背景明暗动态调色与不透明度"
                  subtitle="亮底转黑(0%~50%)，暗底转白(0%~50%)，文字越多磨砂越强(最高5px)"
                  checked={config.color.adaptiveOpacity ?? true}
                  onChange={(checked) => updateColor({ adaptiveOpacity: checked })}
                  accent="pink"
                />

                {/* 实时自适应状态反馈提示 */}
                {(config.color.adaptiveOpacity ?? true) && (() => {
                  const lum = bgLuminance ?? 0.5;
                  const isBright = lum >= 0.5;
                  const t = isBright ? (lum - 0.5) / 0.5 : (0.5 - lum) / 0.5;
                  const currentEstAlpha = Math.round(t * 50);
                  return (
                    <div className={`flex items-center justify-between px-3 py-2 rounded-xl border text-[11px] ${
                      isBright 
                        ? 'bg-neutral-800/80 border-neutral-700 text-neutral-200' 
                        : 'bg-white/10 border-white/20 text-white'
                    }`}>
                      <span className="flex items-center gap-1.5 font-medium">
                        <span>{isBright ? '☀️' : '🌙'}</span>
                        <span>
                          背景亮度: {Math.round(lum * 100)}% (
                          {lum > 0.7 ? '超亮白底' : lum > 0.5 ? '偏亮环境' : lum < 0.3 ? '深色暗底' : '偏暗环境'}
                          )
                        </span>
                      </span>
                      <span className={`font-mono text-[10px] px-2 py-0.5 rounded font-semibold ${
                        isBright ? 'bg-black text-neutral-300 border border-neutral-700' : 'bg-white text-black'
                      }`}>
                        {isBright ? `动态黑调 ~${currentEstAlpha}% (上限50%)` : `动态白调 ~${currentEstAlpha}% (上限50%)`}
                      </span>
                    </div>
                  );
                })()}

                <div className="flex bg-neutral-800 p-1 rounded-xl gap-1 text-xs">
                  {(['solid', 'gradient'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => updateColor({ mode })}
                      className={`flex-1 py-1.5 rounded-lg font-medium transition capitalize ${
                        config.color.mode === mode
                          ? 'bg-pink-500/80 text-white font-semibold shadow'
                          : 'text-neutral-400 hover:text-white'
                      }`}
                    >
                      {mode === 'solid' ? '单色 (Solid)' : '双色渐变 (Gradient)'}
                    </button>
                  ))}
                </div>

                {/* Solid Mode Controls */}
                {config.color.mode === 'solid' && (
                  <div className="space-y-3 pt-2">
                    <SliderRow
                      id="slider-color-solid-a"
                      label="不透明度 (Alpha Opacity)"
                      value={config.color.solid.a}
                      min={0}
                      max={100}
                      unit="%"
                      accent="pink"
                      onChange={(v) => updateColor({ solid: { ...config.color.solid, a: v } })}
                      presets={[
                        { label: '0% (全透)', val: 0 },
                        { label: '10% (高透)', val: 10, isDefault: true },
                        { label: '35%', val: 35 },
                        { label: '70%', val: 70 },
                      ]}
                    />

                    <SliderRow
                      id="slider-color-solid-h"
                      label="色相 (Hue)"
                      value={config.color.solid.h}
                      min={0}
                      max={360}
                      accent="pink"
                      onChange={(v) => updateColor({ solid: { ...config.color.solid, h: v } })}
                    />

                    <SliderRow
                      id="slider-color-solid-s"
                      label="饱和度 (Saturation)"
                      value={config.color.solid.s}
                      min={0}
                      max={100}
                      unit="%"
                      accent="pink"
                      onChange={(v) => updateColor({ solid: { ...config.color.solid, s: v } })}
                    />

                    <SliderRow
                      id="slider-color-solid-l"
                      label="亮度 (Lightness)"
                      value={config.color.solid.l}
                      min={0}
                      max={100}
                      unit="%"
                      accent="pink"
                      onChange={(v) => updateColor({ solid: { ...config.color.solid, l: v } })}
                    />
                  </div>
                )}

                {/* Gradient Mode Controls */}
                {config.color.mode === 'gradient' && (
                  <div className="space-y-3 pt-2">
                    <SliderRow
                      id="slider-color-grad-ratio"
                      label="上下渐变比例 (Gradient Ratio)"
                      value={config.color.gradient.ratio}
                      min={0}
                      max={100}
                      unit="%"
                      accent="pink"
                      onChange={(v) => updateColor({ gradient: { ...config.color.gradient, ratio: v } })}
                    />

                    <SliderRow
                      id="slider-color-grad-top-h"
                      label="顶部色相 (Top Hue)"
                      value={config.color.gradient.top.h}
                      min={0}
                      max={360}
                      accent="pink"
                      onChange={(v) =>
                        updateColor({
                          gradient: {
                            ...config.color.gradient,
                            top: { ...config.color.gradient.top, h: v },
                          },
                        })
                      }
                    />

                    <SliderRow
                      id="slider-color-grad-bottom-h"
                      label="底部色相 (Bottom Hue)"
                      value={config.color.gradient.bottom.h}
                      min={0}
                      max={360}
                      accent="pink"
                      onChange={(v) =>
                        updateColor({
                          gradient: {
                            ...config.color.gradient,
                            bottom: { ...config.color.gradient.bottom, h: v },
                          },
                        })
                      }
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: 高光与外描边 (Highlights & Low Rim) */}
          {activeTab === 'light' && (
            <div className="space-y-3.5">
              {/* 1. 主高光系统 */}
              <SectionCard
                title="高光反射系统 (Highlight System)"
                subtitle="正上方与正下方 90° 双弧白色高光"
                enabled={config.highlight.enabled}
                onToggle={() => updateHighlight({ enabled: !config.highlight.enabled })}
                badgeColor="bg-amber-400"
                accentColor="bg-amber-500"
              >
                <AngleControl
                  id="slider-highlight-angle"
                  label="高光入射角度 (Light Angle)"
                  angle={config.highlight.lightAngle ?? 0}
                  onChange={(deg) => updateHighlight({ lightAngle: deg })}
                  accent="amber"
                />

                <SliderRow
                  id="slider-highlight-master-opacity"
                  label="高光不透明度 (Highlight Opacity)"
                  value={Number((config.highlight.whiteOpacity ?? 33.33).toFixed(2))}
                  min={0}
                  max={100}
                  step={0.01}
                  formatValue={(v) => `${Number(v || 0).toFixed(2)}%`}
                  accent="amber"
                  onChange={(v) => updateHighlight({ whiteOpacity: v, sampleOpacity: v })}
                  presets={[
                    { label: '33.33% (默认)', val: 33.33, isDefault: true },
                    { label: '50%', val: 50 },
                    { label: '75%', val: 75 },
                    { label: '100%', val: 100 },
                  ]}
                />

                <SliderRow
                  id="slider-highlight-blur"
                  label="高光模糊程度 (Highlight Blur)"
                  value={config.highlight.blur ?? 0.0}
                  min={0}
                  max={20}
                  step={0.1}
                  formatValue={(v) => `${Number(v || 0).toFixed(1)} px`}
                  accent="amber"
                  onChange={(v) => updateHighlight({ blur: v })}
                  presets={[
                    { label: '无模糊 0px', val: 0.0, isDefault: true },
                    { label: '微锐 0.5px', val: 0.5 },
                    { label: '柔和 3.0px', val: 3.0 },
                  ]}
                />

                <SliderRow
                  id="slider-highlight-width"
                  label="高光线条宽度 (Highlight Width)"
                  value={config.highlight.width}
                  min={0.5}
                  max={8.0}
                  step={0.1}
                  formatValue={(v) => `${Number(v || 0).toFixed(1)} px`}
                  accent="amber"
                  onChange={(v) => updateHighlight({ width: v })}
                  presets={[
                    { label: '纤细 1.2px (默认)', val: 1.2, isDefault: true },
                    { label: '标准 2.2px', val: 2.2 },
                    { label: '饱满 4.0px', val: 4.0 },
                  ]}
                />
              </SectionCard>
            </div>
          )}

          {/* TAB 6: 阴影 (Shadow) */}
          {activeTab === 'shadow' && (
            <div className="space-y-3.5">
              <SectionCard
                title="外阴影 (Outer Shadow)"
                subtitle="悬浮在背景之上的外轮廓立体落影"
                enabled={config.outerShadow.enabled || config.outerShadow.opacity > 0}
                onToggle={() => {
                  const next = !config.outerShadow.enabled;
                  updateOuterShadow({
                    enabled: next,
                    opacity: next && config.outerShadow.opacity === 0 ? 20 : config.outerShadow.opacity,
                    blur: next && config.outerShadow.blur === 0 ? 40 : config.outerShadow.blur,
                    offsetY: next && config.outerShadow.offsetY === 0 ? 10 : config.outerShadow.offsetY,
                  });
                }}
              >
                <SliderRow
                  id="slider-outer-opacity"
                  label="外阴影不透明度 (Opacity)"
                  value={config.outerShadow.opacity}
                  min={0}
                  max={80}
                  unit="%"
                  accent="emerald"
                  onChange={(v) => updateOuterShadow({ opacity: v, enabled: v > 0 })}
                  presets={[
                    { label: '10%', val: 10 },
                    { label: '20% (默认)', val: 20, isDefault: true },
                    { label: '40%', val: 40 },
                    { label: '60%', val: 60 },
                  ]}
                />
                <SliderRow
                  id="slider-outer-blur"
                  label="外阴影羽化虚化 (Blur Radius)"
                  value={config.outerShadow.blur}
                  min={2}
                  max={80}
                  step={2}
                  unit="px"
                  onChange={(v) => updateOuterShadow({ blur: v })}
                  presets={[
                    { label: '20px', val: 20 },
                    { label: '40px (默认)', val: 40, isDefault: true },
                    { label: '60px', val: 60 },
                  ]}
                />
                <SliderRow
                  id="slider-outer-offset-y"
                  label="垂直落影位置 (Y Offset)"
                  value={config.outerShadow.offsetY}
                  min={-50}
                  max={50}
                  unit="px"
                  onChange={(v) => updateOuterShadow({ offsetY: v })}
                  presets={[
                    { label: '0px (正中)', val: 0 },
                    { label: '10px (默认)', val: 10, isDefault: true },
                    { label: '20px', val: 20 },
                    { label: '30px', val: 30 },
                  ]}
                />
              </SectionCard>

              <SectionCard
                title="内阴影 (Inner Shadow)"
                subtitle="玻璃边缘内部凹陷暗影"
                enabled={config.innerShadow.enabled || config.innerShadow.opacity > 0}
                onToggle={() => {
                  const next = !config.innerShadow.enabled;
                  updateInnerShadow({
                    enabled: next,
                    opacity: next && config.innerShadow.opacity === 0 ? 40 : config.innerShadow.opacity,
                    blur: next && config.innerShadow.blur === 0 ? 20 : config.innerShadow.blur,
                    offsetY: next && config.innerShadow.offsetY === 0 ? 2 : config.innerShadow.offsetY,
                  });
                }}
              >
                <SliderRow
                  id="slider-inner-opacity"
                  label="内阴影不透明度 (Opacity)"
                  value={config.innerShadow.opacity}
                  min={0}
                  max={80}
                  unit="%"
                  accent="cyan"
                  onChange={(v) => updateInnerShadow({ opacity: v, enabled: v > 0 })}
                />
                <SliderRow
                  id="slider-inner-blur"
                  label="内阴影羽化 (Blur Radius)"
                  value={config.innerShadow.blur}
                  min={2}
                  max={60}
                  step={2}
                  unit="px"
                  accent="cyan"
                  onChange={(v) => updateInnerShadow({ blur: v })}
                />
              </SectionCard>
            </div>
          )}

          {/* TAB 7: 形变动画 (Morph Animation) */}
          {activeTab === 'anim' && (
            <div className="space-y-3.5">
              <div className="bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-2xl flex items-center justify-between text-xs">
                <span className="text-emerald-300 font-medium flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  当前形态:
                </span>
                <span className="font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                  {animState.isPlaying ? '动画过渡中...' : config.shape.type.toUpperCase()}
                </span>
              </div>

              {/* Quick Presets */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2">
                <h4 className="text-xs font-bold text-white flex items-center justify-between">
                  <span>一键形态过渡动画</span>
                </h4>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {[
                    { from: 'circle', to: 'capsule', title: '1. 正圆 ➔ 胶囊形' },
                    { from: 'capsule', to: 'circle', title: '2. 胶囊形 ➔ 正圆' },
                    { from: 'circle', to: 'rounded_rect', title: '3. 正圆 ➔ 超椭圆' },
                    { from: 'rounded_rect', to: 'circle', title: '4. 超椭圆 ➔ 正圆' },
                    { from: 'capsule', to: 'rounded_rect', title: '5. 胶囊 ➔ 超椭圆' },
                    { from: 'rounded_rect', to: 'capsule', title: '6. 超椭圆 ➔ 胶囊' },
                  ].map((preset) => (
                    <button
                      key={preset.title}
                      type="button"
                      onClick={() => playAnimation(preset.from, preset.to)}
                      className="p-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left flex flex-col transition active:scale-95 group"
                    >
                      <span className="font-medium text-neutral-200 text-[11px] group-hover:text-emerald-300">
                        {preset.title}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Morph */}
              <div className="bg-neutral-900/60 p-3 rounded-2xl border border-white/10 space-y-2.5">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <RotateCw className="w-3.5 h-3.5 text-emerald-400" />
                  自定义形变过渡
                </h4>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] text-neutral-400">起始形态</label>
                    <select
                      value={animState.fromShape}
                      onChange={(e) => setAnimState((prev) => ({ ...prev, fromShape: e.target.value }))}
                      className="w-full bg-neutral-800 border border-white/15 rounded-xl px-2 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                    >
                      <option value="circle">正圆 (Circle)</option>
                      <option value="capsule">长条胶囊 (Capsule)</option>
                      <option value="rounded_rect">超椭圆矩形 (Squircle)</option>
                      <option value="square_rounded">方圆小岛 (Squircle Island)</option>
                      <option value="pill_small">灵动药丸 (Small Pill)</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-neutral-400">目标形态</label>
                    <select
                      value={animState.toShape}
                      onChange={(e) => setAnimState((prev) => ({ ...prev, toShape: e.target.value }))}
                      className="w-full bg-neutral-800 border border-white/15 rounded-xl px-2 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-400"
                    >
                      <option value="circle">正圆 (Circle)</option>
                      <option value="capsule">长条胶囊 (Capsule)</option>
                      <option value="rounded_rect">超椭圆矩形 (Squircle)</option>
                      <option value="square_rounded">方圆小岛 (Squircle Island)</option>
                      <option value="pill_small">灵动药丸 (Small Pill)</option>
                    </select>
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => playAnimation()}
                    className="w-full py-2 bg-emerald-400 hover:bg-emerald-300 text-black font-bold rounded-xl text-xs transition active:scale-98 flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-400/20"
                  >
                    <PlaySquare className="w-4 h-4" />
                    <span>执行形变动画</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 底部功能栏 (复制配置、导出HTML、重置参数) */}
        <div className="p-3 border-t border-white/10 bg-neutral-900/60 flex items-center justify-between gap-2 text-xs">
          <button
            type="button"
            onClick={handleCopyJSON}
            className="flex-1 py-2 px-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-200 hover:text-white flex items-center justify-center gap-1.5 transition active:scale-95 text-[11px]"
            title="复制着色器与物理参数配置 JSON"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
            <span>{copied ? '已复制' : '复制 JSON'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadHTML}
            className="flex-1 py-2 px-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-200 hover:text-white flex items-center justify-center gap-1.5 transition active:scale-95 text-[11px]"
            title="下载完全独立的单文件 HTML"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>导出 HTML</span>
          </button>

          <button
            type="button"
            onClick={() => onChangeConfig(defaultGlassConfig)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-neutral-400 hover:text-white transition"
            title="恢复默认参数配置"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </aside>
    </>
  );
}
