import React, { ReactNode } from 'react';
import { LucideIcon } from 'lucide-react';

// =============================================================================
// Reusable UI Components for Floating Glass Controls
// =============================================================================

export interface PresetItem {
  label: string;
  val: number;
  isDefault?: boolean;
}

interface SliderRowProps {
  id?: string;
  label: ReactNode;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  formatValue?: (val: number) => string;
  accent?: 'emerald' | 'amber' | 'pink' | 'cyan' | 'white';
  onChange: (val: number) => void;
  presets?: PresetItem[];
  subtext?: ReactNode;
}

const ACCENT_STYLES = {
  emerald: {
    text: 'text-emerald-400',
    slider: 'accent-emerald-400',
    presetActive: 'bg-emerald-400 text-black font-semibold',
  },
  amber: {
    text: 'text-amber-300',
    slider: 'accent-amber-400',
    presetActive: 'bg-amber-400 text-black font-semibold',
  },
  pink: {
    text: 'text-pink-400',
    slider: 'accent-pink-400',
    presetActive: 'bg-pink-400 text-black font-semibold',
  },
  cyan: {
    text: 'text-cyan-400',
    slider: 'accent-cyan-400',
    presetActive: 'bg-cyan-400 text-black font-semibold',
  },
  white: {
    text: 'text-emerald-400',
    slider: 'accent-white',
    presetActive: 'bg-white text-black font-semibold',
  },
};

export function SliderRow({
  id,
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  formatValue,
  accent = 'white',
  onChange,
  presets,
  subtext,
}: SliderRowProps) {
  const styles = ACCENT_STYLES[accent] || ACCENT_STYLES.white;
  const displayVal = formatValue ? formatValue(value) : `${value}${unit ? ` ${unit}` : ''}`;

  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-xs">
        <span className="text-neutral-300 font-medium flex items-center gap-1.5">{label}</span>
        <span className={`font-mono ${styles.text}`}>{displayVal}</span>
      </div>
      <input
        id={id}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`w-full ${styles.slider} bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer`}
      />
      {presets && presets.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          {presets.map((p) => {
            const isSel = Math.abs(value - p.val) <= (step / 2 || 0.05);
            return (
              <button
                key={p.label}
                type="button"
                onClick={() => onChange(p.val)}
                className={`px-2 py-0.5 text-[10px] rounded-md transition ${
                  isSel
                    ? styles.presetActive
                    : 'bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white'
                }`}
              >
                {p.label}
              </button>
            );
          })}
        </div>
      )}
      {subtext && (
        <div className="flex justify-between text-[10px] text-neutral-400 pt-0.5">
          {subtext}
        </div>
      )}
    </div>
  );
}

interface AnglePreset {
  label: string;
  angle: number;
  isDefault?: boolean;
}

const COMMON_ANGLES: AnglePreset[] = [
  { label: '左右 90°', angle: 0, isDefault: true },
  { label: '上下 90°', angle: 90 },
  { label: '右上 45°', angle: 45 },
  { label: '左上 135°', angle: 135 },
  { label: '正左侧 180°', angle: 180 },
  { label: '左下 225°', angle: 225 },
  { label: '正下方 270°', angle: 270 },
  { label: '右下 315°', angle: 315 },
];

export function getAngleDescription(deg: number): string {
  const norm = ((deg % 360) + 360) % 360;
  if (norm >= 352 || norm <= 8) return '左右 90° (默认)';
  if (Math.abs(norm - 90) <= 8) return '上下 90°';
  if (Math.abs(norm - 45) <= 8) return '右上角';
  if (Math.abs(norm - 135) <= 8) return '左上角';
  if (Math.abs(norm - 180) <= 8) return '正左侧';
  if (Math.abs(norm - 225) <= 8) return '左下角';
  if (Math.abs(norm - 270) <= 8) return '正下方';
  if (Math.abs(norm - 315) <= 8) return '右下角';
  return `${Math.round(norm)}°`;
}

interface AngleControlProps {
  id?: string;
  label?: string;
  angle: number;
  onChange: (deg: number) => void;
  accent?: 'amber' | 'pink' | 'emerald';
}

export function AngleControl({
  id = 'slider-angle',
  label = '入射角度 (Angle)',
  angle,
  onChange,
  accent = 'amber',
}: AngleControlProps) {
  const currNorm = ((angle % 360) + 360) % 360;
  const isAmber = accent === 'amber';
  const activeBtnClass = isAmber
    ? 'bg-amber-400/20 border-amber-400 text-amber-300 font-semibold shadow-sm'
    : 'bg-pink-400/20 border-pink-400 text-pink-300 font-semibold shadow-sm';
  const textClass = isAmber ? 'text-amber-300' : 'text-pink-400';
  const sliderAccent = isAmber ? 'accent-amber-400' : 'accent-pink-400';

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs">
        <span className="text-neutral-300 font-medium">{label}</span>
        <span className={`font-mono ${textClass}`}>
          {Math.round(currNorm)}° ({getAngleDescription(currNorm)})
        </span>
      </div>
      <input
        id={id}
        type="range"
        min="0"
        max="360"
        step="1"
        value={currNorm}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`w-full ${sliderAccent} bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer`}
      />
      <div className="grid grid-cols-3 gap-1 pt-1">
        {COMMON_ANGLES.map((pos) => {
          const isSelected = Math.abs(currNorm - pos.angle) < 4;
          return (
            <button
              key={pos.angle}
              type="button"
              onClick={() => onChange(pos.angle)}
              className={`px-2 py-1.5 text-[11px] rounded-lg border transition flex items-center justify-between ${
                isSelected
                  ? activeBtnClass
                  : 'bg-white/5 border-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <span className="truncate">{pos.label}</span>
              {pos.isDefault && (
                <span className="text-[9px] px-1 py-0.2 bg-white/20 text-white rounded font-normal">
                  默认
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

interface SectionCardProps {
  title: ReactNode;
  subtitle?: ReactNode;
  enabled: boolean;
  onToggle?: () => void;
  toggleId?: string;
  badgeColor?: string;
  accentColor?: string;
  children: ReactNode;
}

export function SectionCard({
  title,
  subtitle,
  enabled,
  onToggle,
  toggleId,
  badgeColor = 'bg-emerald-400',
  accentColor = 'bg-emerald-500',
  children,
}: SectionCardProps) {
  return (
    <div className="bg-neutral-800/50 p-3.5 rounded-2xl border border-white/10 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${badgeColor}`} />
            {title}
          </h4>
          {subtitle && <p className="text-[10px] text-neutral-400 mt-0.5">{subtitle}</p>}
        </div>
        {onToggle && (
          <button
            id={toggleId}
            type="button"
            onClick={onToggle}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition active:scale-95 ${
              enabled ? `${accentColor} text-black` : 'bg-white/10 text-neutral-400 hover:text-white'
            }`}
          >
            {enabled ? '已开启 (ON)' : '已关闭 (OFF)'}
          </button>
        )}
      </div>
      {enabled && <div className="space-y-2.5 pt-1.5 border-t border-white/5">{children}</div>}
    </div>
  );
}

interface TabButtonProps {
  id: string;
  active: boolean;
  onClick: () => void;
  icon: LucideIcon;
  label: string;
  badge?: ReactNode;
  activeClass?: string;
  iconClass?: string;
  title?: string;
}

export function ToggleRow({
  id,
  label,
  subtitle,
  checked,
  onChange,
  accent = 'pink',
}: {
  id: string;
  label: string;
  subtitle?: string;
  checked: boolean;
  onChange: (val: boolean) => void;
  accent?: 'emerald' | 'amber' | 'pink' | 'cyan' | 'purple';
}) {
  const accentClasses = {
    emerald: 'bg-emerald-400',
    amber: 'bg-amber-400',
    pink: 'bg-pink-500',
    cyan: 'bg-cyan-400',
    purple: 'bg-purple-500',
  }[accent];

  return (
    <div className="flex items-center justify-between p-2.5 rounded-xl bg-neutral-900/60 border border-white/10">
      <div className="space-y-0.5 pr-2">
        <label htmlFor={id} className="text-xs font-semibold text-neutral-200 cursor-pointer block">
          {label}
        </label>
        {subtitle && <p className="text-[10px] text-neutral-400 leading-tight">{subtitle}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
          checked ? accentClasses : 'bg-neutral-700'
        }`}
      >
        <span
          className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
            checked ? 'translate-x-4' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}

export function TabButton({
  id,
  active,
  onClick,
  icon: Icon,
  label,
  badge,
  activeClass = 'bg-white text-black font-semibold',
  iconClass = 'w-3.5 h-3.5',
  title,
}: TabButtonProps) {
  return (
    <button
      id={id}
      type="button"
      onClick={onClick}
      title={title}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition active:scale-95 ${
        active ? activeClass : 'text-neutral-300 hover:text-white hover:bg-white/10'
      }`}
    >
      <Icon className={iconClass} />
      <span>{label}</span>
      {badge}
    </button>
  );
}

