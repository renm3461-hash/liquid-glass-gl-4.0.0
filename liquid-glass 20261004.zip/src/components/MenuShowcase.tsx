import React, { useState } from 'react';

export default function MenuShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activePreset, setActivePreset] = useState(0);

  const menuCards = [
    { id: 0, title: '音乐随行', subtitle: 'Apple Liquid Player', icon: '🎵', color: 'from-pink-500/20 to-purple-500/20' },
    { id: 1, title: '天气环境', subtitle: '晴朗 24°C • 优质空气', icon: '☀️', color: 'from-amber-500/20 to-orange-500/20' },
    { id: 2, title: '智能家居', subtitle: '3 个设备已就绪', icon: '🏠', color: 'from-cyan-500/20 to-blue-500/20' },
    { id: 3, title: '快捷指令', subtitle: '一键运行工作流', icon: '⚡', color: 'from-emerald-500/20 to-teal-500/20' },
  ];

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-6 pointer-events-none">
      <div className="pointer-events-auto grid grid-cols-2 gap-4 w-full max-w-lg">
        {menuCards.map((card) => {
          const isSelected = activePreset === card.id;
          return (
            <button
              key={card.id}
              onClick={() => {
                setActivePreset(card.id);
                if (card.id === 0) setIsPlaying(!isPlaying);
              }}
              className={`group text-left p-4 rounded-3xl backdrop-blur-3xl border transition-all duration-300 relative overflow-hidden ${
                isSelected
                  ? 'bg-neutral-900/60 border-white/40 shadow-[0_20px_50px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.5)] scale-[1.02]'
                  : 'bg-neutral-950/40 border-white/10 hover:border-white/20 hover:bg-neutral-900/40 shadow-lg'
              }`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${card.color} opacity-40 pointer-events-none transition-opacity group-hover:opacity-60`} />
              
              <div className="relative z-10 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-xl shadow-inner">
                    {card.icon}
                  </div>
                  {card.id === 0 && (
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${isPlaying ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 animate-pulse' : 'bg-white/10 border-white/10 text-neutral-400'}`}>
                      {isPlaying ? '播放中' : '暂停'}
                    </span>
                  )}
                </div>

                <div>
                  <h4 className="font-semibold text-sm text-white">{card.title}</h4>
                  <p className="text-xs text-neutral-300/80 mt-0.5">{card.subtitle}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
