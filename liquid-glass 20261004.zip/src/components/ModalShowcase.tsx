import React, { useState } from 'react';

export default function ModalShowcase() {
  const [activeTab, setActiveTab] = useState<'info' | 'settings'>('info');
  const [toggleVal, setToggleVal] = useState(true);

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-4 pointer-events-none">
      <div className="pointer-events-auto relative w-full max-w-md rounded-3xl bg-neutral-950/40 backdrop-blur-3xl border border-white/20 p-6 shadow-[0_25px_60px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.4)] text-white space-y-5 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-400 to-emerald-400 flex items-center justify-center text-black font-bold text-lg shadow-lg shadow-cyan-500/20">
              💎
            </div>
            <div>
              <h3 className="font-semibold text-base text-white tracking-wide">液态玻璃交互卡片</h3>
              <p className="text-xs text-neutral-400">Apple G2 连续曲率超椭圆折射系统</p>
            </div>
          </div>
          <div className="flex bg-white/10 p-0.5 rounded-full border border-white/10 text-xs">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-3 py-1 rounded-full transition ${activeTab === 'info' ? 'bg-white text-black font-semibold shadow' : 'text-neutral-300 hover:text-white'}`}
            >
              详情
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3 py-1 rounded-full transition ${activeTab === 'settings' ? 'bg-white text-black font-semibold shadow' : 'text-neutral-300 hover:text-white'}`}
            >
              控制
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'info' ? (
          <div className="space-y-3.5 text-xs text-neutral-300 leading-relaxed">
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <div className="flex justify-between items-center text-white font-medium">
                <span>实时光线折射 (Refraction)</span>
                <span className="text-emerald-400 font-mono">1.52 IOR</span>
              </div>
              <p className="text-neutral-400 text-[11px]">
                基于真实物理几何 SDF 与 55° G2 级贝塞尔切线接管，模拟高密度玻璃的色散 (Dispersion) 与双重外发光阴影。
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
                <span className="text-neutral-400 text-[11px]">流体融合度</span>
                <span className="text-lg font-bold text-cyan-300 font-mono">100% G2</span>
              </div>
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between">
                <span className="text-neutral-400 text-[11px]">高光采样</span>
                <span className="text-lg font-bold text-emerald-300 font-mono">Dual Spec</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10">
              <div>
                <p className="font-medium text-white">开启物理流体拟真</p>
                <p className="text-[11px] text-neutral-400">自动响应手势拖拽与速度拉伸</p>
              </div>
              <button
                onClick={() => setToggleVal(!toggleVal)}
                className={`w-11 h-6 rounded-full transition-colors p-0.5 relative ${toggleVal ? 'bg-emerald-400' : 'bg-white/20'}`}
              >
                <div className={`w-5 h-5 rounded-full bg-neutral-900 transition-transform ${toggleVal ? 'translate-x-5 bg-black' : 'translate-x-0'}`} />
              </button>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            className="flex-1 py-2.5 rounded-xl bg-white text-black font-semibold text-xs hover:bg-neutral-200 transition active:scale-95 shadow-lg"
          >
            确认应用
          </button>
        </div>
      </div>
    </div>
  );
}
