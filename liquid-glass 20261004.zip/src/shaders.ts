export const vertexShaderSource = `
  attribute vec2 a_position;
  void main() {
    gl_Position = vec4(a_position, 0.0, 1.0);
  }
`;

export const fragmentShaderSource = `
  precision highp float;
  uniform sampler2D u_texture;
  uniform vec2 u_resolution;
  uniform vec2 u_screenSize;
  uniform vec2 u_texResolution;
  uniform vec2 u_uvScale;
  uniform vec2 u_uvOffset;
  uniform float u_glassRadius;
  uniform float u_refraction;
  uniform float u_edgeWidth;
  uniform float u_dispersion;
  uniform vec2 u_lightDir;
  uniform vec2 u_boxSize;
  uniform float u_shapeType;
  uniform float u_blurRadius;
  uniform float u_bgBlur;
  uniform vec4 u_glassColor;
  uniform vec4 u_glassColor2;
  uniform float u_colorMode;
  uniform float u_gradientRatio;
  uniform float u_highlightEnable;
  uniform float u_highlightFeather;
  uniform float u_highlightWidth;
  uniform float u_highlightWhiteOpacity;
  uniform float u_highlightSampleOpacity;
  uniform float u_highlightReflectDist;
  uniform float u_highlightClarity;
  uniform float u_highlightBlur;
  uniform float u_cssRatio;
  uniform float u_highlightScale;
  uniform float u_liquidBridge;
  uniform float u_fluidIntensity;
  uniform float u_hasBg;
  uniform float u_adaptiveOpacity;
  uniform float u_bgLuminance;

  uniform float u_outerShadowEnable;
  uniform vec4 u_outerShadowColor;
  uniform vec2 u_outerShadowOffset;
  uniform float u_outerShadowBlur;

  uniform float u_innerShadowEnable;
  uniform vec4 u_innerShadowColor;
  uniform vec2 u_innerShadowOffset;
  uniform float u_innerShadowBlur;

  uniform vec2 u_clickGlowPos;
  uniform float u_clickGlowIntensity;
  uniform float u_clickGlowRadius;
  uniform float u_clickGlowProgress;
  uniform vec2 u_pullVec;
  uniform int u_activeGlassIndex;
  
  // GPU-accelerated cover UV mapping using uniforms precomputed once per frame on CPU
  vec2 getCoverUV(vec2 pos) {
      return (pos / u_resolution) * u_uvScale + u_uvOffset;
  }

  // Exact 16-point taper intensity progression recommended by user:
  // [0, 10, 19.52, 28.57, 37.14, 45.24, 52.86, 60, 66.67, 72.86, 78.57, 83.81, 88.57, 92.86, 96.67, 100]
  // Monotonically and smoothly strengthens from the thin needle tip (0%) to the thick central end (100%)
  float getUserHlIntensity(float t) {
      float clampedT = clamp(t, 0.0, 1.0);
      float scaled = clampedT * 15.0;
      int idx = int(floor(scaled));
      float f = fract(scaled);

      float v0 = 0.0;
      float v1 = 0.1000;

      if (idx == 0) { v0 = 0.0000; v1 = 0.1000; }
      else if (idx == 1) { v0 = 0.1000; v1 = 0.1952; }
      else if (idx == 2) { v0 = 0.1952; v1 = 0.2857; }
      else if (idx == 3) { v0 = 0.2857; v1 = 0.3714; }
      else if (idx == 4) { v0 = 0.3714; v1 = 0.4524; }
      else if (idx == 5) { v0 = 0.4524; v1 = 0.5286; }
      else if (idx == 6) { v0 = 0.5286; v1 = 0.6000; }
      else if (idx == 7) { v0 = 0.6000; v1 = 0.6667; }
      else if (idx == 8) { v0 = 0.6667; v1 = 0.7286; }
      else if (idx == 9) { v0 = 0.7286; v1 = 0.7857; }
      else if (idx == 10) { v0 = 0.7857; v1 = 0.8381; }
      else if (idx == 11) { v0 = 0.8381; v1 = 0.8857; }
      else if (idx == 12) { v0 = 0.8857; v1 = 0.9286; }
      else if (idx == 13) { v0 = 0.9286; v1 = 0.9667; }
      else { v0 = 0.9667; v1 = 1.0000; }

      return mix(v0, v1, f);
  }

  // Optical continuous isotropic Gaussian blur (42 multi-ring taps)
  // Dense concentric rings with interleaved phase offsets and zero screen-space noise
  // Completely eliminates all ripples, moiré waves, banding, and grain across all blur radii
  vec4 getBlurredBg(vec2 uv, float radius) {
      if (u_hasBg < 0.5) return vec4(0.0);
      if (radius <= 0.05) return texture2D(u_texture, clamp(uv, 0.0, 1.0));
      
      vec2 stepUV = (radius / u_screenSize) * u_uvScale;
      
      // Ring 0: Center tap (weight = 1.0)
      vec4 sum = texture2D(u_texture, clamp(uv, 0.0, 1.0));
      float totalW = 1.0;
      
      // Ring 1: 5 taps at r = 0.22, phase = 0.0 (w = 0.908)
      const float W1 = 0.908;
      const float R1 = 0.22;
      for (int i = 0; i < 5; i++) {
          float a = float(i) * 1.256637;
          vec2 p = uv + vec2(cos(a), sin(a)) * (R1 * stepUV);
          sum += texture2D(u_texture, clamp(p, 0.0, 1.0)) * W1;
      }
      totalW += 5.0 * W1;
      
      // Ring 2: 8 taps at r = 0.44, phase = 0.392699 (w = 0.679)
      const float W2 = 0.679;
      const float R2 = 0.44;
      for (int i = 0; i < 8; i++) {
          float a = float(i) * 0.785398 + 0.392699;
          vec2 p = uv + vec2(cos(a), sin(a)) * (R2 * stepUV);
          sum += texture2D(u_texture, clamp(p, 0.0, 1.0)) * W2;
      }
      totalW += 8.0 * W2;
      
      // Ring 3: 12 taps at r = 0.68, phase = 0.261799 (w = 0.396)
      const float W3 = 0.396;
      const float R3 = 0.68;
      for (int i = 0; i < 12; i++) {
          float a = float(i) * 0.523599 + 0.261799;
          vec2 p = uv + vec2(cos(a), sin(a)) * (R3 * stepUV);
          sum += texture2D(u_texture, clamp(p, 0.0, 1.0)) * W3;
      }
      totalW += 12.0 * W3;
      
      // Ring 4: 16 taps at r = 0.95, phase = 0.196350 (w = 0.164)
      const float W4 = 0.164;
      const float R4 = 0.95;
      for (int i = 0; i < 16; i++) {
          float a = float(i) * 0.392699 + 0.196350;
          vec2 p = uv + vec2(cos(a), sin(a)) * (R4 * stepUV);
          sum += texture2D(u_texture, clamp(p, 0.0, 1.0)) * W4;
      }
      totalW += 16.0 * W4;
      
      return sum / totalW;
  }

  #define MAX_GLASSES 12
  uniform vec2 u_glassPosArr[MAX_GLASSES];
  uniform vec2 u_velocityArr[MAX_GLASSES];
  uniform float u_clickScaleArr[MAX_GLASSES];
  uniform float u_connectedMaskArr[MAX_GLASSES];
  uniform float u_whitenessArr[MAX_GLASSES];
  uniform float u_bgLuminanceArr[MAX_GLASSES];
  uniform float u_shapeTypeArr[MAX_GLASSES];
  uniform vec2 u_boxSizeArr[MAX_GLASSES];
  uniform float u_glassRadiusArr[MAX_GLASSES];
  uniform int u_numGlasses;

  // Exact Equidistant G2 Capsule Distance Field and Normal Evaluation
  // Guarantees strictly equidistant, equal-width offset rim around the entire perimeter.
  // The straight (un-tilted) section maintains true equal-width distance to the outer boundary.
  void evalG2Capsule(vec2 p, vec2 boxSize, float R, out float outDist, out float outDistFromEdge, out vec2 outNormal) {
      bool isVertical = boxSize.y > boxSize.x;
      float S0 = isVertical ? boxSize.y : boxSize.x;
      
      // Canonical coordinates in the first quadrant
      float u = isVertical ? abs(p.y) : abs(p.x);
      float v = isVertical ? abs(p.x) : abs(p.y);

      float theta = 0.959931; // 55 deg
      float half_t = theta * 0.5;
      float sin_h = sin(half_t);
      float cos_h = cos(half_t);
      float tan_h = sin_h / cos_h;
      
      float x2 = R * tan_h;
      float L = (0.75 * R * sin_h) / (cos_h * cos_h * cos_h);
      float x1_raw = x2 - L;
      float x0_raw = x1_raw - L;

      float max_space = max(0.0, S0);
      if (-x0_raw > max_space && max_space > 0.001) {
          float scale = max_space / (-x0_raw);
          theta *= scale;
          half_t = theta * 0.5;
          sin_h = sin(half_t);
          cos_h = cos(half_t);
          tan_h = sin_h / cos_h;
          x2 = R * tan_h;
          L = (0.75 * R * sin_h) / (cos_h * cos_h * cos_h);
          x1_raw = x2 - L;
          x0_raw = x1_raw - L;
      }

      float x0 = x0_raw;
      float x1 = x1_raw;

      float sin_t = sin(theta);
      float cos_t = cos(theta);
      float dx3 = R * sin_t;
      float dy3 = R * (1.0 - cos_t);

      float px = u - S0;
      float py = v;

      float dEdge = 0.0;
      vec2 norm_canonical = vec2(0.0, 1.0);

      // Section 1: Un-tilted straight spine section (px <= x0)
      if (px <= x0) {
          dEdge = R - py;
          norm_canonical = vec2(0.0, 1.0);
      }
      // Section 2: Seamless continuous end-cap section (px > x0)
      else {
          vec2 w = vec2(px - x0, py);
          float lenW = length(w);
          if (lenW < 0.0001) {
              dEdge = R;
              norm_canonical = vec2(0.0, 1.0);
          } else {
              vec2 dirW = w / lenW;
              vec2 w3 = vec2(dx3 - x0, R - dy3);

              vec2 P_outer = vec2(0.0);

              // Sub-branch A: Ray hits circular arc (w.y * w3.x <= w.x * w3.y)
              if (w.y * w3.x <= w.x * w3.y) {
                  // Ray from (x0, 0) intersects circle X^2 + Y^2 = R^2
                  // lambda^2 + 2*x0*dirW.x*lambda + (x0^2 - R^2) = 0
                  float b = -x0 * dirW.x;
                  float disc = max(0.0, b * b + R * R - x0 * x0);
                  float lambda = b + sqrt(disc);
                  P_outer = vec2(x0, 0.0) + dirW * lambda;
                  norm_canonical = length(P_outer) > 0.0001 ? normalize(P_outer) : vec2(1.0, 0.0);
              }
              // Sub-branch B: Ray hits G2 Bezier curve (w.y * w3.x > w.x * w3.y)
              else {
                  float t = clamp((dirW.x > 0.0001) ? (dirW.x * lenW) / max(0.001, dx3 - x0) : 0.5, 0.0, 1.0);
                  for (int iter = 0; iter < 5; iter++) {
                      float omt = 1.0 - t;
                      float xt = omt * omt * omt * x0 + 3.0 * omt * omt * t * x1 + 3.0 * omt * t * t * x2 + t * t * t * dx3;
                      float yt = max(0.001, R - t * t * t * dy3);

                      float dxt = 3.0 * (omt * omt * (x1 - x0) + 2.0 * omt * t * (x2 - x1) + t * t * (dx3 - x2));
                      float dyt = -3.0 * t * t * dy3;

                      float fVal = yt * dirW.x - (xt - x0) * dirW.y;
                      float fDeriv = dyt * dirW.x - dxt * dirW.y;
                      t = clamp(t - fVal / (abs(fDeriv) > 0.0001 ? fDeriv : -1.0), 0.0, 1.0);
                  }

                  float omt = 1.0 - t;
                  float xt = omt * omt * omt * x0 + 3.0 * omt * omt * t * x1 + 3.0 * omt * t * t * x2 + t * t * t * dx3;
                  float yt = max(0.001, R - t * t * t * dy3);
                  P_outer = vec2(xt, yt);

                  float dxt = 3.0 * (omt * omt * (x1 - x0) + 2.0 * omt * t * (x2 - x1) + t * t * (dx3 - x2));
                  float dyt = -3.0 * t * t * dy3;
                  norm_canonical = normalize(vec2(-dyt, dxt));
              }

              dEdge = dot(P_outer - vec2(px, py), norm_canonical);
          }
      }

      // Exact equidistant internal coordinates:
      // Distance from core/spine outDist in [0, R], strictly equidistant from outer perimeter all the way around
      outDist = max(0.0, R - dEdge);
      outDistFromEdge = dEdge;

      float signX = p.x < 0.0 ? -1.0 : 1.0;
      float signY = p.y < 0.0 ? -1.0 : 1.0;

      if (isVertical) {
          outNormal = vec2(signX * norm_canonical.y, signY * norm_canonical.x);
      } else {
          outNormal = vec2(signX * norm_canonical.x, signY * norm_canonical.y);
      }
  }

  // Evaluates exact SDF, normalized radial distance [0, 1], and surface normal for a glass item
  void evalGlassSDF(
      vec2 pos,
      float scale,
      vec2 velocity,
      float sType,
      vec2 bSize,
      float gRadius,
      bool isPulled,
      vec2 pixelPos,
      out float outSDF,
      out float outDistFromEdge,
      out float outR,
      out vec2 outNormal
  ) {
      vec2 p = (pixelPos - pos) / scale;
      
      // Dynamic pull/drag stretch when pinned
      if (isPulled && (u_pullVec.x != 0.0 || u_pullVec.y != 0.0)) {
          float pullLen = length(u_pullVec);
          if (pullLen > 0.001) {
              vec2 pullDir = u_pullVec / pullLen;
              float pPara = dot(p, pullDir);
              vec2 ortho = vec2(-pullDir.y, pullDir.x);
              float pOrtho = dot(p, ortho);

              float stretchAmount = 1.0 + min(pullLen * 0.0004, 0.12);
              float squishAmount = 1.0 / sqrt(stretchAmount);

              p = pullDir * (pPara / stretchAmount) + ortho * (pOrtho * squishAmount);
          }
      }
      
      // Dynamic velocity inertia stretch
      float speed = length(velocity);
      if (speed > 0.1) {
          vec2 vDir = velocity / speed;
          float pPara = dot(p, vDir);
          vec2 ortho = vec2(-vDir.y, vDir.x);
          float pOrtho = dot(p, ortho);

          float maxSpeed = min(speed, 45.0);
          float intensity = u_fluidIntensity / 50.0;
          float stretch = 1.0 + maxSpeed * 0.008 * intensity; 
          float squish = 1.0 + maxSpeed * 0.004 * intensity; 
          
          pPara /= stretch;
          pOrtho *= squish; 
          
          p = vDir * pPara + ortho * pOrtho;
      }

      if (abs(sType - 1.0) < 0.1) { // 1.0: G2 5-Segment Bezier Capsule
          float distCore = 0.0;
          float dEdge = 0.0;
          vec2 normVec = vec2(0.0, 1.0);
          evalG2Capsule(p, bSize, gRadius, distCore, dEdge, normVec);
          outSDF = -dEdge * scale;
          outDistFromEdge = max(0.0, dEdge * scale);
          outR = clamp(distCore / gRadius, 0.0, 1.0);
          outNormal = normVec;
      } else if (abs(sType - 2.0) < 0.1) { // 2.0: Circle
          float d = length(p);
          outSDF = (d - gRadius) * scale;
          outDistFromEdge = max(0.0, (gRadius - d) * scale);
          outR = clamp(d / gRadius, 0.0, 1.0);
          outNormal = d > 0.0001 ? p / d : vec2(0.0, 0.0);
      } else { // 0.0: Strict Apple Superellipse Squircle (G2 Curvature continuous)
          vec2 pt = p;
          pt.x -= clamp(pt.x, -bSize.x, bSize.x);
          pt.y -= clamp(pt.y, -bSize.y, bSize.y);
          vec2 abs_p = abs(pt);
          float sq_n = 3.4;
          float d = pow(pow(abs_p.x + 1e-6, sq_n) + pow(abs_p.y + 1e-6, sq_n), 1.0 / sq_n);
          outSDF = (d - gRadius) * scale;
          outDistFromEdge = max(0.0, (gRadius - d) * scale);
          outR = clamp(d / gRadius, 0.0, 1.0);
          vec2 grad = sign(pt) * pow(abs_p + vec2(1e-6), vec2(sq_n - 1.0));
          outNormal = d > 0.0001 ? normalize(grad) : vec2(0.0, 0.0);
      }
  }

  // Combined Multi-Glass SDF & Optical Data Evaluation
  void getShapeData(
      vec2 pixelPos,
      out float outSDF,
      out float outDistFromEdge,
      out float outR,
      out vec2 outNormal,
      out float outWhiteness,
      out float outLum,
      out float outAlpha
  ) {
      float mergedSDF = 9999.0;
      float mergedDistFromEdge = 0.0;
      float mergedR = 0.0;
      vec2 mergedNormal = vec2(0.0);
      float mergedWhiteness = 0.0;
      float mergedLum = 0.5;
      
      // Liquid bridge smooth-minimum blend radius (rich, organic fluid neck)
      float smin_k = (u_liquidBridge / 50.0) * 60.0 + (u_liquidBridge > 0.1 ? 6.0 : 0.0);

      for (int i = 0; i < MAX_GLASSES; i++) {
          if (i >= u_numGlasses) break;

          vec2 pos = u_glassPosArr[i];
          float scale = max(0.01, u_clickScaleArr[i]);
          vec2 velocity = u_velocityArr[i];
          float sType = u_shapeTypeArr[i];
          vec2 bSize = u_boxSizeArr[i];
          float gRadius = max(1.0, u_glassRadiusArr[i]);
          float curWhite = u_whitenessArr[i];
          float curLum = u_bgLuminanceArr[i];
          bool isPulled = (i == u_activeGlassIndex);

          float curSDF = 0.0;
          float curEdge = 0.0;
          float curR = 0.0;
          vec2 curNormal = vec2(0.0);
          evalGlassSDF(pos, scale, velocity, sType, bSize, gRadius, isPulled, pixelPos, curSDF, curEdge, curR, curNormal);

          if (i == 0) {
              mergedSDF = curSDF;
              mergedDistFromEdge = curEdge;
              mergedR = curR;
              mergedNormal = curNormal;
              mergedWhiteness = curWhite;
              mergedLum = curLum;
          } else {
              if (smin_k > 0.5) {
                  float h = clamp(0.5 + 0.5 * (mergedSDF - curSDF) / smin_k, 0.0, 1.0);
                  mergedSDF = mix(mergedSDF, curSDF, h) - smin_k * h * (1.0 - h);
                  mergedDistFromEdge = mix(mergedDistFromEdge, curEdge, h);
                  mergedR = mix(mergedR, curR, h);
                  mergedNormal = mix(mergedNormal, curNormal, h);
                  mergedWhiteness = mix(mergedWhiteness, curWhite, h);
                  mergedLum = mix(mergedLum, curLum, h);
              } else {
                  if (curSDF < mergedSDF) {
                      mergedSDF = curSDF;
                      mergedDistFromEdge = curEdge;
                      mergedR = curR;
                      mergedNormal = curNormal;
                      mergedWhiteness = curWhite;
                      mergedLum = curLum;
                  }
              }
          }
      }

      if (length(mergedNormal) > 0.0001) {
          mergedNormal = normalize(mergedNormal);
      } else {
          mergedNormal = vec2(0.0, 0.0);
      }

      outSDF = mergedSDF;
      outDistFromEdge = max(0.0, -mergedSDF);
      outR = clamp(mergedR, 0.0, 1.0);
      outNormal = mergedNormal;
      outWhiteness = mergedWhiteness;
      outLum = mergedLum;
      // High-precision anti-aliasing across glass boundaries
      outAlpha = smoothstep(0.8, -0.8, mergedSDF);
  }

  // Exact natural optical falloff curve evaluated via Hermite cubic profile (zero branches/lookups)
  float getNaturalGlowFalloff(float r) {
      if (r >= 1.0) return 0.0;
      if (r <= 0.0) return 1.0;
      float d = 1.0 - r;
      return d * d * (3.0 - 2.0 * d);
  }

  void main() {
      vec2 pixelPos = vec2(gl_FragCoord.x, u_resolution.y - gl_FragCoord.y);

      float glassSDF = 9999.0;
      float distFromEdge = 0.0;
      float r = 0.0;
      vec2 normal = vec2(0.0);
      float whiteness = 0.0;
      float localLum = 0.5;
      float shapeAlpha = 0.0;
      
      getShapeData(pixelPos, glassSDF, distFromEdge, r, normal, whiteness, localLum, shapeAlpha);
      vec2 dir = length(normal) > 0.0001 ? normalize(normal) : vec2(0.0, 0.0);

      // Outer Shadow (Soft realistic ambient shadow - accelerated distance field)
      float outerShadowFactor = 0.0;
      if (u_outerShadowEnable > 0.5 && u_outerShadowColor.a > 0.001) {
          vec2 shPos = pixelPos - u_outerShadowOffset;
          float shSDF = 9999.0;
          float dummyEdge = 0.0, dummyR = 0.0, dummyW = 0.0, dummyL = 0.5, dummyAlpha = 0.0;
          vec2 dummyNorm = vec2(0.0);
          getShapeData(shPos, shSDF, dummyEdge, dummyR, dummyNorm, dummyW, dummyL, dummyAlpha);

          float blurVal = max(1.0, u_outerShadowBlur);
          float distOutside = max(0.0, shSDF);
          float shadowFalloff = smoothstep(blurVal * 2.5, 0.0, distOutside);
          outerShadowFactor = shadowFalloff * shadowFalloff;
      }

      if (shapeAlpha <= 0.0 && outerShadowFactor <= 0.0) {
          gl_FragColor = vec4(0.0);
          return;
      }

      vec4 glassCol = vec4(0.0);

      if (shapeAlpha > 0.0) {
          // 1. Base continuous curvature: smoothly transitions from center (r ~ 0) without threshold rings
          float gamma = mix(4.6, 2.2, clamp(u_edgeWidth * 1.5, 0.0, 1.0));
          float baseCurve = pow(r, gamma);

          // 2. Asymptotic grazing-angle steepener: simulates steepening 3D droplet meniscus slope dz/dr -> infinity
          float rimSteep = (r * r) / max(0.01, 1.04 - 0.96 * r);
          float normalizedRim = clamp(rimSteep * 0.08, 0.0, 1.0);

          // Unified C2 continuous profile: near-zero at center, explosive acceleration at outer rim
          float profile = baseCurve * mix(0.35, 1.0, normalizedRim);

          // Dynamic refraction gain: scaled by refraction strength and edge geometry
          float maxRefractDist = u_refraction * 60.0 * mix(0.7, 1.6, clamp(u_edgeWidth, 0.2, 0.8));
          float offset = profile * maxRefractDist;

          vec2 samplePos = pixelPos - dir * offset;

          // 3. Chromatic dispersion: concentrated strictly at the high-deflection peripheral rim
          float dispersionFalloff = pow(r, 3.5);
          float dispersionAmount = offset * dispersionFalloff * u_dispersion * 0.32;

          // Preserve peripheral chromatic clarity so dispersion fringes are not smeared out by interior volume blur
          float edgeClarity = smoothstep(0.65, 1.0, r);
          float clampedInternal = clamp(u_blurRadius, 0.0, 10.0);
          float localFrostedBlur = mix(clampedInternal, clampedInternal * 0.35, edgeClarity * clamp(u_dispersion * 0.8, 0.0, 0.8));

          vec4 glassContext = vec4(0.0);
          if (u_hasBg > 0.5) {
              if (dispersionAmount > 0.5) {
                  float rChan = getBlurredBg(getCoverUV(samplePos + dir * dispersionAmount), localFrostedBlur).r;
                  float gChan = getBlurredBg(getCoverUV(samplePos), localFrostedBlur).g;
                  float bChan = getBlurredBg(getCoverUV(samplePos - dir * dispersionAmount), localFrostedBlur).b;
                  glassContext = vec4(rChan, gChan, bChan, 1.0);
              } else {
                  glassContext = getBlurredBg(getCoverUV(samplePos), localFrostedBlur);
              }
          }

          vec4 activeGlassColor = u_glassColor;
          if (u_colorMode > 0.5) {
              vec2 primaryP = (pixelPos - u_glassPosArr[0]) / max(0.01, u_clickScaleArr[0]);
              float glassHalfHeight = max(10.0, u_glassRadiusArr[0] + u_boxSizeArr[0].y);
              float normY = clamp((primaryP.y / max(1.0, glassHalfHeight)) * 0.5 + 0.5, 0.0, 1.0);
              float ratio = clamp(u_gradientRatio, 0.01, 0.99);
              float exponent = log(0.5) / log(ratio);
              float gradT = pow(normY, exponent);
              activeGlassColor = mix(u_glassColor, u_glassColor2, gradT);
          }

          vec3 finalColorRgb = activeGlassColor.rgb;
          float finalColorAlpha = activeGlassColor.a;

          if (u_adaptiveOpacity > 0.5 && u_hasBg > 0.5) {
              // Read per-glass local background luminance
              float sceneLum = clamp(localLum, 0.0, 1.0);

              // 1. Ultra-silky color cross-fade: smooth Hermite transition between pure White (0.0) and pure Black (1.0)
              float colorT = smoothstep(0.38, 0.62, sceneLum);
              finalColorRgb = mix(vec3(1.0), vec3(0.0), colorT);

              // 2. Smooth C2 continuous opacity curve: zero slope at 0.5, completely eliminates V-kinks
              if (sceneLum >= 0.5) {
                  float t = clamp((sceneLum - 0.5) / 0.5, 0.0, 1.0);
                  float curve = smoothstep(0.0, 1.0, t);
                  finalColorAlpha = 0.50 * curve;
              } else {
                  float t = clamp((0.5 - sceneLum) / 0.5, 0.0, 1.0);
                  float curve = smoothstep(0.0, 1.0, t);
                  finalColorAlpha = 0.50 * curve;
              }
          }

          if (u_hasBg > 0.5) {
              glassContext.rgb = mix(glassContext.rgb, finalColorRgb, finalColorAlpha);
              glassCol = glassContext;
          } else {
              glassCol = vec4(finalColorRgb, finalColorAlpha);
          }

          // Liquid bridge / contact whitening: fused glasses smoothly turn pure milky white (80% opacity)
          if (whiteness > 0.001) {
              float wFactor = clamp(whiteness, 0.0, 1.0);
              glassCol.rgb = mix(glassCol.rgb, vec3(1.0), wFactor * 0.85);
              glassCol.a = mix(glassCol.a, max(glassCol.a, 0.80), wFactor * 0.80);
          }

          // -------------------------------------------------------------
          // Dynamic Specular Rim Highlights & Dark Rim (Physically Calibrated)
          // -------------------------------------------------------------
          
          vec2 normLight = length(u_lightDir) > 0.001 ? normalize(u_lightDir) : vec2(0.0, -1.0);
          vec2 primaryHlDir = normLight;
          vec2 secondaryHlDir = -normLight;

          // Angular crescent taper along perimeter normal
          float dotHl1 = dot(dir, primaryHlDir);
          float dotHl2 = dot(dir, secondaryHlDir);

          // Span from cutoff angle to facing center
          const float hlCutoff = -0.05;
          float t1 = clamp((dotHl1 - hlCutoff) / (1.0 - hlCutoff), 0.0, 1.0);
          float t2 = clamp((dotHl2 - hlCutoff) / (1.0 - hlCutoff), 0.0, 1.0);

          // User-calibrated 16-point taper intensity progression:
          float intensity1 = getUserHlIntensity(t1) * 0.70;
          float intensity2 = getUserHlIntensity(t2) * 0.70;

          // Tangible, solid specular highlight with user-controlled width and ZERO flicker
          float baseHlW = max(1.0, u_highlightWidth);
          float userBlur = max(0.0, u_highlightBlur * 0.5);
          float userFeather = max(0.0, u_highlightFeather * 1.5);
          float totalSoftness = userBlur + userFeather;

          // Sub-pixel anti-aliasing feather zone
          float aa = 0.85 + totalSoftness;

          // Primary crescent (Top/Light Facing)
          float localW1 = baseHlW * 0.75 * mix(0.18, 1.0, intensity1);
          float halfW1 = localW1 * 0.5;
          float hlCenter1 = max(0.8, localW1 * 0.55);
          float dHl1 = abs(distFromEdge - hlCenter1);

          float cs1 = 1.0 - smoothstep(max(0.0, halfW1 - aa), halfW1 + aa, dHl1);
          float hlFactor1 = cs1 * intensity1 * smoothstep(0.0, 0.25, dotHl1);

          // Secondary crescent (Opposing)
          float localW2 = baseHlW * 0.75 * mix(0.18, 1.0, intensity2);
          float halfW2 = localW2 * 0.5;
          float hlCenter2 = max(0.8, localW2 * 0.55);
          float dHl2 = abs(distFromEdge - hlCenter2);
          float cs2 = 1.0 - smoothstep(max(0.0, halfW2 - aa), halfW2 + aa, dHl2);
          float hlFactor2 = cs2 * intensity2 * smoothstep(0.0, 0.25, dotHl2);

          float totalHlFactor = max(hlFactor1, hlFactor2);

          // Specular highlight environment sample & mix
          vec3 highlightSampleColor = vec3(1.0);
          if (u_highlightEnable > 0.5 && totalHlFactor > 0.0001) {
              if (u_hasBg > 0.5) {
                  vec2 dirNorm = length(normal) > 0.0001 ? normalize(normal) : vec2(0.0, 1.0);
                  vec2 reflectPos = pixelPos + dirNorm * u_highlightReflectDist;
                  vec2 reflectUV = getCoverUV(reflectPos);
                  
                  float clarityFactor = clamp(u_highlightClarity / 100.0, 0.0, 1.0);
                  float reflectBlur = max(0.0, (1.0 - clarityFactor) * 8.0);
                  vec4 reflectBgColor = getBlurredBg(reflectUV, reflectBlur);
                  
                  vec3 rawCol = reflectBgColor.rgb;
                  float lum = dot(rawCol, vec3(0.299, 0.587, 0.114));
                  vec3 brightenedCol = max(rawCol, vec3(0.35));
                  if (lum > 0.01) {
                      float boost = max(1.0, 0.75 / max(0.2, lum));
                      brightenedCol = min(vec3(1.0), rawCol * boost);
                  }
                  highlightSampleColor = brightenedCol;
              }

              float whiteAlpha = clamp(u_highlightWhiteOpacity / 100.0, 0.0, 1.0);
              float sampleAlpha = clamp(u_highlightSampleOpacity / 100.0, 0.0, 1.0);
              
              vec3 hlColor = vec3(1.0);
              float sumAlpha = whiteAlpha + sampleAlpha;
              if (sumAlpha > 0.001) {
                  hlColor = mix(vec3(1.0), highlightSampleColor, sampleAlpha / sumAlpha);
              }
              
              float totalHlOpacity = clamp(max(whiteAlpha, sampleAlpha), 0.0, 1.0);
              float effectiveHl = clamp(totalHlFactor, 0.0, 1.0);
              
              float hlStrength = effectiveHl * totalHlOpacity;
              vec3 specularGleam = hlColor * hlStrength;
              glassCol.rgb = mix(glassCol.rgb, hlColor, hlStrength * 0.95) + specularGleam * 0.45;
              glassCol.rgb = clamp(glassCol.rgb, 0.0, 1.0);
              glassCol.a = max(glassCol.a, hlStrength);
          }

          // Inner Shadow (Accelerated distance field)
          if (u_innerShadowEnable > 0.5 && u_innerShadowColor.a > 0.001) {
              vec2 inPos = pixelPos - u_innerShadowOffset;
              float inSDF = 9999.0;
              float dummyE = 0.0, dummyR2 = 0.0, dummyW2 = 0.0, dummyL2 = 0.5, dummyA = 0.0;
              vec2 dummyN = vec2(0.0);
              getShapeData(inPos, inSDF, dummyE, dummyR2, dummyN, dummyW2, dummyL2, dummyA);

              float inBlurVal = max(1.0, u_innerShadowBlur);
              float innerShadowFactor = smoothstep(-inBlurVal * 1.5, 0.0, inSDF);
              innerShadowFactor *= shapeAlpha;
              glassCol.rgb = mix(glassCol.rgb, u_innerShadowColor.rgb, u_innerShadowColor.a * innerShadowFactor);
          }

          // Natural Optical Falloff Glass Internal Illumination (Direct light propagation on touch)
          if (u_clickGlowIntensity > 0.0005) {
              float clickDist = length(pixelPos - u_clickGlowPos);
              float rNorm = clickDist / max(1.0, u_clickGlowRadius);
              float totalGlow = getNaturalGlowFalloff(rNorm) * u_clickGlowIntensity;
              
              glassCol.rgb = mix(glassCol.rgb, vec3(1.0), totalGlow * 0.65);
              glassCol.a = clamp(glassCol.a + totalGlow * 0.25, 0.0, 1.0);
          }

          glassCol.a *= shapeAlpha;
      }

      vec4 outerShadowCol = vec4(u_outerShadowColor.rgb, u_outerShadowColor.a * outerShadowFactor);

      // Premultiply alpha for correct browser HTML compositing
      if (shapeAlpha <= 0.001) {
          gl_FragColor = vec4(outerShadowCol.rgb * outerShadowCol.a, outerShadowCol.a);
      } else if (outerShadowFactor <= 0.001) {
          gl_FragColor = vec4(glassCol.rgb * glassCol.a, glassCol.a);
      } else {
          float shadowBehindAlpha = outerShadowCol.a * (1.0 - shapeAlpha);
          vec3 glassPremul = glassCol.rgb * glassCol.a;
          vec3 shadowPremul = outerShadowCol.rgb * shadowBehindAlpha;

          vec3 blendedRGB = glassPremul + shadowPremul * (1.0 - glassCol.a);
          float blendedA = glassCol.a + shadowBehindAlpha * (1.0 - glassCol.a);
          gl_FragColor = vec4(blendedRGB, blendedA);
      }
  }
`;

