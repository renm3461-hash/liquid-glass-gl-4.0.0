/**
 * 超平滑 G2 胶囊 (终极防切边完美版) 几何生成算法
 * - 100% 忠实还原原版 HTML 算法逻辑，支持横向 (w >= h) 与竖向 (h > w) 全方向渲染
 * - 基于 G2 级三次贝塞尔过渡曲线平滑接管半圆弧
 * - 动态回退机制：当胶囊长宽比较小时自动自适应动态减小接管角度，防止几何干涉
 * - 0.01px 安全容差注入：防止原生 SVG 浮点数舍入导致圆弧被浏览器压平
 */

export interface CapsuleGeometryResult {
  path: string;
  clipPathCss: string;
  actualAngle: number;
  isCompressed: boolean;
  isVertical: boolean;
  isTooCloseToSquare: boolean;
}

export function generateFlawlessCapsule(
  w: number,
  h: number,
  requestedAngle: number = 55
): CapsuleGeometryResult {
  const isVertical = h > w;
  const f = (val: number) => Number(val.toFixed(4));

  if (!isVertical) {
    // -------------------------------------------------------------
    // 横向胶囊 (Width >= Height)
    // -------------------------------------------------------------
    const R = h / 2;
    const max_space = Math.max(0, (w - 2 * R) / 2);

    let theta = requestedAngle * (Math.PI / 180);
    let L = 0,
      x2 = 0,
      x1 = 0,
      x0 = 0;

    // 动态回退机制：如果胶囊太短容不下这么大的平滑过渡，自动减小角度
    let steps = 0;
    while (theta > 0.001 && steps < 100) {
      const half_t = theta / 2;
      x2 = R * Math.tan(half_t);
      L = (0.75 * R * Math.sin(half_t)) / Math.pow(Math.cos(half_t), 3);
      x1 = x2 - L;
      x0 = x1 - L; // 向内推挤的距离

      // 如果没有越过中心线，就算数学上安全
      if (Math.abs(x0) <= max_space) break;

      theta -= 0.01;
      steps++;
    }

    const actualAngle = (theta * 180) / Math.PI;
    const isCompressed = actualAngle < requestedAngle - 0.5;

    // 真正的交界点坐标
    const dx3 = R * Math.sin(theta);
    const dy3 = R * (1 - Math.cos(theta));

    const cxR = w - R;
    const cxL = R;

    // 【核心修复】防止原生 SVG 因为四舍五入判定距离超限而把圆弧压平
    const safe_R = f(R + 0.01);

    // 右侧几何控制点
    const tr_P0 = { x: cxR + x0, y: 0 };
    const tr_P1 = { x: cxR + x1, y: 0 };
    const tr_P2 = { x: cxR + x2, y: 0 };
    const tr_P3 = { x: cxR + dx3, y: dy3 };

    const br_P3 = { x: cxR + dx3, y: h - dy3 };
    const br_P2 = { x: cxR + x2, y: h };
    const br_P1 = { x: cxR + x1, y: h };
    const br_P0 = { x: cxR + x0, y: h };

    // 左侧几何控制点
    const bl_P0 = { x: cxL - x0, y: h };
    const bl_P1 = { x: cxL - x1, y: h };
    const bl_P2 = { x: cxL - x2, y: h };
    const bl_P3 = { x: cxL - dx3, y: h - dy3 };

    const tl_P3 = { x: cxL - dx3, y: dy3 };
    const tl_P2 = { x: cxL - x2, y: 0 };
    const tl_P1 = { x: cxL - x1, y: 0 };
    const tl_P0 = { x: cxL - x0, y: 0 };

    let p = `M ${f(tl_P0.x)} 0 `;
    p += `L ${f(tr_P0.x)} 0 `;
    p += `C ${f(tr_P1.x)} ${f(tr_P1.y)}, ${f(tr_P2.x)} ${f(tr_P2.y)}, ${f(tr_P3.x)} ${f(tr_P3.y)} `;
    p += `A ${safe_R} ${safe_R} 0 0 1 ${f(br_P3.x)} ${f(br_P3.y)} `;
    p += `C ${f(br_P2.x)} ${f(br_P2.y)}, ${f(br_P1.x)} ${f(br_P1.y)}, ${f(br_P0.x)} ${f(br_P0.y)} `;
    p += `L ${f(bl_P0.x)} ${f(h)} `;
    p += `C ${f(bl_P1.x)} ${f(bl_P1.y)}, ${f(bl_P2.x)} ${f(bl_P2.y)}, ${f(bl_P3.x)} ${f(bl_P3.y)} `;
    p += `A ${safe_R} ${safe_R} 0 0 1 ${f(tl_P3.x)} ${f(tl_P3.y)} `;
    p += `C ${f(tl_P2.x)} ${f(tl_P2.y)}, ${f(tl_P1.x)} ${f(tl_P1.y)}, ${f(tl_P0.x)} ${f(tl_P0.y)} `;
    p += `Z`;

    return {
      path: p,
      clipPathCss: `path('${p}')`,
      actualAngle,
      isCompressed,
      isVertical: false,
      isTooCloseToSquare: isCompressed && actualAngle < 5.0,
    };
  } else {
    // -------------------------------------------------------------
    // 竖向胶囊 (Height > Width)
    // -------------------------------------------------------------
    const R = w / 2;
    const max_space = Math.max(0, (h - 2 * R) / 2);

    let theta = requestedAngle * (Math.PI / 180);
    let L = 0,
      y2 = 0,
      y1 = 0,
      y0 = 0;

    let steps = 0;
    while (theta > 0.001 && steps < 100) {
      const half_t = theta / 2;
      y2 = R * Math.tan(half_t);
      L = (0.75 * R * Math.sin(half_t)) / Math.pow(Math.cos(half_t), 3);
      y1 = y2 - L;
      y0 = y1 - L;

      if (Math.abs(y0) <= max_space) break;

      theta -= 0.01;
      steps++;
    }

    const actualAngle = (theta * 180) / Math.PI;
    const isCompressed = actualAngle < requestedAngle - 0.5;

    const dx3 = R * Math.sin(theta);
    const dy3 = R * (1 - Math.cos(theta));

    const cyT = R;
    const cyB = h - R;
    const safe_R = f(R + 0.01);

    const tr_P0 = { x: w, y: cyT + y0 };
    const tr_P1 = { x: w, y: cyT + y1 };
    const tr_P2 = { x: w, y: cyT + y2 };
    const tr_P3 = { x: w - dy3, y: cyT - dx3 };

    const tl_P3 = { x: dy3, y: cyT - dx3 };
    const tl_P2 = { x: 0, y: cyT + y2 };
    const tl_P1 = { x: 0, y: cyT + y1 };
    const tl_P0 = { x: 0, y: cyT + y0 };

    const bl_P0 = { x: 0, y: cyB - y0 };
    const bl_P1 = { x: 0, y: cyB - y1 };
    const bl_P2 = { x: 0, y: cyB - y2 };
    const bl_P3 = { x: dy3, y: cyB + dx3 };

    const br_P3 = { x: w - dy3, y: cyB + dx3 };
    const br_P2 = { x: w, y: cyB - y2 };
    const br_P1 = { x: w, y: cyB - y1 };
    const br_P0 = { x: w, y: cyB - y0 };

    let p = `M ${f(w)} ${f(tr_P0.y)} `;
    p += `C ${f(tr_P1.x)} ${f(tr_P1.y)}, ${f(tr_P2.x)} ${f(tr_P2.y)}, ${f(tr_P3.x)} ${f(tr_P3.y)} `;
    p += `A ${safe_R} ${safe_R} 0 0 0 ${f(tl_P3.x)} ${f(tl_P3.y)} `;
    p += `C ${f(tl_P2.x)} ${f(tl_P2.y)}, ${f(tl_P1.x)} ${f(tl_P1.y)}, ${f(tl_P0.x)} ${f(tl_P0.y)} `;
    p += `L 0 ${f(bl_P0.y)} `;
    p += `C ${f(bl_P1.x)} ${f(bl_P1.y)}, ${f(bl_P2.x)} ${f(bl_P2.y)}, ${f(bl_P3.x)} ${f(bl_P3.y)} `;
    p += `A ${safe_R} ${safe_R} 0 0 0 ${f(br_P3.x)} ${f(br_P3.y)} `;
    p += `C ${f(br_P2.x)} ${f(br_P2.y)}, ${f(br_P1.x)} ${f(br_P1.y)}, ${f(br_P0.x)} ${f(br_P0.y)} `;
    p += `Z`;

    return {
      path: p,
      clipPathCss: `path('${p}')`,
      actualAngle,
      isCompressed,
      isVertical: true,
      isTooCloseToSquare: isCompressed && actualAngle < 5.0,
    };
  }
}
