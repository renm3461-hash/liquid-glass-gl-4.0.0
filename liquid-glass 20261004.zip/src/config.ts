// =============================================================================
// 液态玻璃着色器与物理模拟参数配置 (Glass Simulation Parameters)
// 您可以直接在此代码中调整所有参数，画布与着色器将自动实时应用。
// =============================================================================

export interface GlassConfig {
  // --- 背景设置 (Background) ---
  bg: {
    type: 'image' | 'video';
    src: string; // 图片或视频 URL，支持线上地址与本地资源
    blur: number; // 背景虚化模糊 (Background blur, 0 - 10 px)
  };

  // --- 形状与几何尺寸 (Shape & Dimensions) ---
  shape: {
    type: 'circle' | 'capsule' | 'rounded_rect';
    size: number;          // 圆形半径 (Circle Radius) (px)
    rectW: number;         // 矩形/胶囊宽度 (Width) (px)
    rectH: number;         // 矩形/胶囊高度 (Height) (px)
    cornerRadius: number;  // 超椭圆矩形半径 (Superellipse Radius) (px)
  };

  // --- 光学折射与流体融合 (Optics & Physics) ---
  optics: {
    refraction: number;    // 折射强度 (Refraction strength, 0 - 200)
    edgeWidth: number;     // 边缘曲率宽度 (Edge bevel width, 0 - 100)
    dispersion: number;    // 色散棱镜彩虹效果 (Dispersion / Chromatic Aberration, 0 - 100)
    blurRadius: number;    // 玻璃内部毛玻璃模糊 (Internal frosted blur, 0 - 10 px)
    liquidBridge: number;  // 液态流体融合桥接强度 (Liquid metaball bridge, 0 - 50)
    fluidIntensity: number;// 高速移动流体形变强度 (Fluid deformation intensity on fast move, 0 - 100)
  };

  // --- 颜色与渐变 (Color & Gradient) ---
  color: {
    mode: 'solid' | 'gradient'; // 'solid' 单色 | 'gradient' 渐变
    adaptiveOpacity: boolean;   // 随背景明暗自适应调节不透明度 (默认开启)
    solid: {
      h: number; // 色相 (Hue 0-360)
      s: number; // 饱和度 (Saturation 0-100)
      l: number; // 亮度 (Lightness 0-100)
      a: number; // 不透明度 (Alpha 0-100)
    };
    gradient: {
      ratio: number; // 渐变上下分界比例 (0-100)
      top: { h: number; s: number; l: number; a: number };
      bottom: { h: number; s: number; l: number; a: number };
    };
  };

  // --- 镜面高光与环境反射 (Specular Highlight & Environment Sample) ---
  highlight: {
    enabled: boolean;          // 是否开启高光
    lightAngle: number;        // 光源角度 (Light angle in degrees, 0 - 360)
    width: number;             // 高光线条宽度 (Highlight line width)
    feather: number;           // 高光边缘羽化 (Feather softness)
    whiteOpacity: number;      // 纯白高光不透明度 (White opacity, 0 - 100)
    sampleOpacity: number;     // 环境采样反射不透明度 (Sample opacity, 0 - 100)
    reflectDist: number;       // 外部采样反射距离 (Sample distance in px)
    clarity: number;           // 采样清晰度 (Sample clarity, 0 - 100)
    blur: number;              // 采样模糊强度 (Sample blur, 0 - 30 px)
  };

  // --- 外投影 (Outer Shadow) ---
  outerShadow: {
    enabled: boolean;
    color: string;             // HEX
    opacity: number;           // 0 - 100
    offsetX: number;           // X 轴偏移 (px)
    offsetY: number;           // Y 轴偏移 (px)
    blur: number;              // 模糊半径 (px)
  };

  // --- 内阴影 (Inner Shadow) ---
  innerShadow: {
    enabled: boolean;
    color: string;             // HEX
    opacity: number;           // 0 - 100
    offsetX: number;           // X 轴偏移 (px)
    offsetY: number;           // Y 轴偏移 (px)
    blur: number;              // 模糊半径 (px)
  };
}

export const DEFAULT_GLASS_CONFIG: GlassConfig = {
  bg: {
    type: 'image',
    src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=85', // 默认精选瑞士雪山湖泊自然风景
    blur: 0.0, // 默认背景模糊 0px (0 - 10px)
  },
  shape: {
    type: 'capsule',
    size: 60,
    rectW: 320,
    rectH: 120,
    cornerRadius: 60,
  },
  optics: {
    refraction: 100,
    edgeWidth: 10,
    dispersion: 45,
    blurRadius: 0.0, // 默认内部模糊 0.0px (0 - 10px)
    liquidBridge: 20,
    fluidIntensity: 50,
  },
  color: {
    mode: 'solid',
    adaptiveOpacity: true, // 默认开启：随背景明暗自动调节不透明度
    solid: { h: 0, s: 0, l: 100, a: 10 },
    gradient: {
      ratio: 50,
      top: { h: 200, s: 80, l: 90, a: 15 },
      bottom: { h: 280, s: 70, l: 85, a: 10 },
    },
  },
  highlight: {
    enabled: true,
    lightAngle: 0,  // 默认 0° (左右 90 度：正左与正右双弧高光)
    width: 1.2,     // 默认高光宽度 1.2px (纤细)
    feather: 0.15,
    whiteOpacity: 33.33, // 默认高光不透明度 33.33%
    sampleOpacity: 33.33,
    reflectDist: 25,
    clarity: 100,
    blur: 0.0, // 高光模糊程度 (无模糊，默认 0.0px)
  },
  outerShadow: {
    enabled: true,
    color: '#000000',
    opacity: 20,
    offsetX: 0,
    offsetY: 10,
    blur: 40,
  },
  innerShadow: {
    enabled: false, // 默认关闭内阴影，保证边缘无任何多余描边
    color: '#000000',
    opacity: 0,
    offsetX: 0,
    offsetY: 0,
    blur: 50,
  },
};

export const defaultGlassConfig = DEFAULT_GLASS_CONFIG;

