# liquid-glass-gl

物理级液态玻璃渲染器 NPM 包 —— 液态玻璃参考项目 **20261004 Gemini 液桥修订版**的忠实移植（v4.0：真 SDF 跨形状液桥 + 接触变白 + 每玻璃独立变色；**已移除相互吸引效果**）。

所有玻璃在**同一个 WebGL 渲染层**内**实时**渲染（纯 shader 计算，无任何贴图伪造），玻璃之间通过 smin metaball 场**液态融合**，并且**每个实例拥有完全独立的参数**（形状 / 光学 / 色彩 / 高光 / 阴影）。

着色器数学、物理弹簧参数与默认值**逐行照抄**自参考项目：

- 精确等距 **G2 五段贝塞尔胶囊 SDF**（55° 接管角 + 动态回退）
- Apple 严格连续曲率**超椭圆 Squircle**（指数 3.4）
- **折射**（C2 连续弯月面剖面 + 掠射角陡化）
- **色散**（RGB 三通道分离，能量集中于边缘 r^3.5）
- **42-tap 同心环高斯模糊**（5+8+12+16 采样，无摩尔纹）
- **双弧镜面高光**（16 点用户校准锥形强度表 + 环境采样增亮反射）
- **外阴影 / 内阴影**（加速距离场）
- **液态融合桥接**（Inigo Quilez 多项式 smooth-min）+ **融合集群乳白化**
- **跨形状液桥**（参考版算法）：液桥颈部由**真实符号距离场**上的多项式平滑最小值 `smin_k = (liquidBridge/50)×60 + 6` 直接生成 —— 任意两块不同形状（胶囊 / 超椭圆 / 圆形）靠近时都会长出有机流体颈，桥内自带折射 / 高光 / 色散
- **接触变白**（参考版算法）：两玻璃表面间距小于 `max(14, (liquidBridge/50)×48 + 10)` 时，接触双方平滑变乳白（85% 白 / 80% 透明度），分开后自动回落（lerp 0.20）；玻璃之间**没有吸引效果**（已按需求移除）
- **每玻璃独立变色**：每块玻璃各自采样所在位置的背景亮度（死区 [0.42, 0.58] / 斜率 1.15 / 速率 0.04 平滑适应），独立驱动黑白调色与不透明度
- **点击光晕**（Hermite 自然衰减）+ **按压缩放**（二阶弹簧 1.08）
- **钉住拉伸**（pullVec 局部表面形变 + 弹性回位）
- **自适应亮度调色**（亮底转黑 0–50%、暗底转白 0–50%）+ **文字密度磨砂**（Sobel + 5×5 池化，最高 5px）
- 速度驱动**流动态形变**（每玻璃独立速度拉伸/挤压）
- 陀螺仪 / 桌面鼠标倾斜模拟（二阶弹簧惯性）

## 安装

```bash
npm install liquid-glass-gl
# 或
bun add liquid-glass-gl
```

无任何运行时依赖，纯 DOM + WebGL API。

## 快速开始

```ts
import { LiquidGlassLayer, DEFAULT_GLASS_CONFIG } from 'liquid-glass-gl';

// 1. 准备一个容器元素（会自动注入背景媒体 + WebGL 画布）
const layer = new LiquidGlassLayer({
  container: document.getElementById('stage')!,
  onSelect: (glass) => console.log('选中玻璃', glass.id),
  onGlassesChange: (glasses) => console.log('玻璃列表变化', glasses.length),
});

// 2. 设置背景（图片或视频，折射/高光采样的来源）
layer.setBackground({
  type: 'image',
  src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=85',
  blur: 0, // 0 - 10px 背景虚化（纹理上传前物理高斯模糊）
});

// 3. 添加玻璃 —— 每个实例参数完全独立
const capsule = layer.addGlass({
  pos: { x: window.innerWidth / 2, y: window.innerHeight / 2 },
  config: DEFAULT_GLASS_CONFIG, // 可传 DeepPartial 局部覆盖
});

const circle = layer.addGlass({
  pos: { x: 300, y: 300 },
  config: {
    shape: { type: 'circle', size: 85 },
    optics: { dispersion: 80 },
    highlight: { lightAngle: 90 },
  },
});

// 4. 独立修改某个实例的参数（实时生效，无需重建）
circle.update({ optics: { refraction: 160, dispersion: 60 } });

// 4b. 液桥强度（每实例独立；两玻璃各取平均决定桥颈宽度与接触阈值）
circle.update({ optics: { liquidBridge: 40 } }); // 0 - 50，越大颈部越宽、接触越早

// 5. 形变动画（照抄原版 fluidBounce 缓动 + 逐过渡对圆角逻辑）
capsule.morphTo({ type: 'rounded_rect', rectW: 340, rectH: 160 }, 220);

// 6. 钉住模式（固定位置 + pullVec 拉伸形变 + 光晕跟随 + 弹性回位）
layer.setPinned(true);

// 销毁
layer.destroy();
```

## API

### `new LiquidGlassLayer(options)`

| 选项 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `container` | `HTMLElement` | `document.body` | 宿主元素，画布与背景媒体注入其中 |
| `canvas` | `HTMLCanvasElement` | 自动创建 | 可选传入已有画布 |
| `pinned` | `boolean` | `false` | 初始是否为钉住（固定拖动）模式 |
| `maxGlasses` | `number` | `12` | 最大玻璃数（着色器上限 12） |
| `onSelect` | `(glass) => void` | — | 抓取某块玻璃时回调 |
| `onGlassesChange` | `(glasses) => void` | — | 玻璃增删时回调 |
| `onBackgroundError` | `(src) => void` | — | 背景加载失败回调 |
| `onBackgroundLoad` | `(src) => void` | — | 背景加载完成回调 |

### 实例方法（渲染层）

| 方法 | 说明 |
|---|---|
| `addGlass({ pos?, config?, popIn? })` | 添加玻璃（返回 `GlassInstance`，满员返回 `null`）。不传 `pos` 时按原版中心随机偏移 + pop-in 弹出动画 |
| `removeGlass(glass)` | 移除指定玻璃 |
| `clearExtras()` | 仅保留第一块（原版"清理多余"） |
| `resetGlasses()` | 原版重置布局（2 块 ±120px / 环形排布） |
| `setBackground({ type, src, blur })` | 设置图片/视频背景与虚化（0–10px） |
| `setPinned(v)` / `togglePinned()` | 钉住模式开关 |
| `requestRender()` | 请求下一帧渲染（自动合帧） |
| `startAnimationLoop()` | 启动物理循环（内部使用） |
| `getViewSize()` | 容器尺寸 |
| `destroy()` | 移除监听 / 删除 GL 资源 / 卸载 DOM |

### `GlassInstance`

| 成员 | 说明 |
|---|---|
| `id` | 只读自增 ID |
| `config` | 完整独立的 `GlassConfig` |
| `update(patch)` | 深合并局部参数（`DeepPartial<GlassConfig>`） |
| `setConfig(cfg)` / `resetConfig()` | 整体替换 / 恢复默认 |
| `morphTo(target, duration)` | 形状形变动画（原版 `animateMorphTo`） |
| `setPosition(x, y)` / `glideTo(x, y)` | 立即 / 弹性滑移 |
| `onChange(cb)` / `offChange(cb)` | 参数变化监听（面板同步用） |
| `pos` / `velocity` / `clickScale` / `whiteness` | 实时物理状态（可读） |
| `currLum` / `currTextBlur` | 平滑后的局部背景亮度 / 文字磨砂值 |

### `GlassConfig` 结构（与原版逐字段一致）

`bg`（图层级）· `shape`（circle / capsule / rounded_rect 及尺寸）· `optics`（refraction 0–200、edgeWidth 0–100、dispersion 0–100、blurRadius 0–10、liquidBridge 0–50、fluidIntensity 0–100）· `color`（solid/gradient HSLA + 自适应明暗开关）· `highlight`（角度 0–360、宽度、羽化、白色/采样不透明度、反射距离、清晰度、模糊）· `outerShadow` / `innerShadow`（颜色、不透明度、偏移、羽化）。默认值见 `DEFAULT_GLASS_CONFIG`（胶囊 320×120、折射 100、色散 45、液桥 20 等，与参考版完全相同）。

## 多实例融合说明

所有玻璃共享一次 `drawArrays` 全屏绘制；着色器内按**每玻璃独立求出的真实 SDF**（含各自形状 / 尺寸 / 点击缩放 / 速度形变）求 smin 合成场，归一化径向坐标 r 也按每玻璃求值后混合（保证超椭圆等形状调色均匀）。像素级参数（折射/色散/颜色/高光/阴影）以与距离场**相同的 smin 权重 h** 平滑混合——分离时各归各（与单玻璃参考版逐像素一致），融合时自然过渡。接触变白严格按参考版：只有真正接触的双方变乳白。

## 限制

- WebGL 1（所有现代浏览器可用）。
- 单层最多 12 块玻璃（着色器常量 `MAX_GLASSES`）。
- 背景跨域图片需服务端返回 CORS 头（Unsplash 已支持），否则纹理上传会被画布污染保护拦截。

## License

MIT
